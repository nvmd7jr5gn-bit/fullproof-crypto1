// Public, unauthenticated search helper. Output is advisory; manually verify market rules.
import { PolymarketUS } from 'polymarket-us';
const query = process.argv.slice(2).join(' ') || 'Bitcoin Up or Down 5 minute';
const client = new PolymarketUS();
const result = await client.search.query({ query });
process.stdout.write(JSON.stringify({ query, result }, null, 2) + '\n');
