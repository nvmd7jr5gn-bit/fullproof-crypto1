// Public, unauthenticated Polymarket US contract inspection. No trading methods.
// Usage: node inspect_market.mjs <market-slug>
import { PolymarketUS } from 'polymarket-us';
const slug = process.argv[2];
if (!slug) {
  console.error('Pass a Polymarket US market slug.');
  process.exit(2);
}
const client = new PolymarketUS();
const result = await client.markets.retrieveBySlug(slug);
const market = result?.market ?? result;
const terms = market?.assetPriceTerms ?? null;
const sides = (market?.marketSides ?? []).map(side => ({
  id: side.id, description: side.description, long: side.long, tradable: side.tradable,
}));
process.stdout.write(JSON.stringify({
  requestedSlug: slug, returnedSlug: market?.slug, question: market?.question,
  active: market?.active, closed: market?.closed, status: market?.status,
  sides, assetPriceTerms: terms, rulesDisclaimer: market?.rulesDisclaimer,
}, null, 2) + '\n');
