// Read-only Polymarket US market-data bridge. Deliberately imports no order/trading APIs.
// Usage: POLYMARKET_KEY_ID=... POLYMARKET_SECRET_KEY=... node market_stream.mjs <market-slug[,market-slug...]>
import { PolymarketUS } from 'polymarket-us';

const slugs = (process.argv[2] || '').split(',').map(x => x.trim()).filter(Boolean);
if (!slugs.length) {
  console.error('Pass one or more verified Polymarket US market slugs.');
  process.exit(2);
}
const keyId = process.env.POLYMARKET_KEY_ID;
const secretKey = process.env.POLYMARKET_SECRET_KEY;
if (!keyId || !secretKey) {
  console.error('Missing Polymarket US market-stream credentials in environment.');
  process.exit(2);
}

const client = new PolymarketUS({ keyId, secretKey });
const ws = client.ws.markets();
const emit = (type, payload) => process.stdout.write(JSON.stringify({
  type, received_at: new Date().toISOString(), payload
}) + '\n');
ws.on('marketData', data => emit('marketData', data));
ws.on('marketDataLite', data => emit('marketDataLite', data));
ws.on('trade', data => emit('trade', data));
ws.on('heartbeat', data => emit('heartbeat', data));
ws.on('error', error => emit('error', { message: String(error?.message || error) }));
ws.on('close', data => emit('close', data || {}));
await ws.connect();
ws.subscribeMarketData('fullproof-md-1', slugs);
ws.subscribeTrades('fullproof-trades-1', slugs);
process.on('SIGINT', () => { ws.close(); process.exit(0); });
process.on('SIGTERM', () => { ws.close(); process.exit(0); });
