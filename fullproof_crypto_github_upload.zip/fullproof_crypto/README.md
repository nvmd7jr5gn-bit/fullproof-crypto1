# FullProof Crypto — BTC 5-Minute Polymarket US Signals

**Status:** research starter / paper-only. **No order placement, cancellation, wallet access, or automated trading code.**

The configured research bankroll is **$2,500**, with moderate-risk paper limits. The default maximum hypothetical entry exposure is 1% of bankroll ($25), the daily paper loss stop is 3% ($75), and the global open-position cap is one. These are configurable research controls, not validated betting parameters or a recommendation to risk money.

## Current implementation

- BTC feature engineering using causal/past-only returns, EMA spread, RSI, realized volatility, rolling volume z-score, distance from market open, and order-book imbalance.
- Two-model probability ensemble (regularized logistic regression + histogram gradient boosting).
- **Chronological out-of-sample Platt calibration:** base models fit only on earlier market windows; the calibrator sees a later segment. Whole `market_id` groups are kept on one side of each split to avoid leaking highly correlated snapshots from the same five-minute contract across the boundary.
- Market-level chronological holdout and expanding-window walk-forward metrics: accuracy, balanced accuracy, Brier score, log loss, expected calibration error, and reliability buckets.
- A continuously updating multi-swing state machine: `HOLD`, `BUY_UP`, `BUY_DOWN`, `EXIT_UP`, `EXIT_DOWN`, `UP_INVALIDATED`, and `DOWN_INVALIDATED`. It supports re-entry and reversals within one five-minute market, but only after fresh evidence and executable price checks.
- Entry evidence requires calibrated probabilities, candle body/close-location structure, momentum, rolling volume z-score, volatility, order-book imbalance, side-specific ask depth, quote freshness, probability threshold, and net edge after configured fee/slippage assumptions.
- Identical REST payloads are deduplicated; unchanged polls cannot satisfy consecutive-entry confirmation. Exits/invalidation react faster than entries. If a usable bid/depth is absent, the engine records an exit-pending state instead of pretending a position was closed.
- Global open-position cap and daily paper-loss stop. One hypothetical paper position is allowed by default across markets. Fill-missed alerts do not consume exposure capacity, and active/pending signal state is restored from SQLite after process restarts.
- `PaperSignalCoordinator` connects normalized snapshots to the state machine, SQLite event ledger, entry/exit accounting, mark-to-market, and official-resolution settlement hook.
- Separate records for alerts, fillable hypothetical entries, missed entries, risk-blocked entries, swing exits, and settlement. Alerts are never automatically treated as fills.
- Swing-vs-hold-to-expiry replay evaluation on eligible chronological holdout data. Every swing entry and exit incurs configured transaction-cost assumptions. Reports net/gross P&L, drawdown, losing streak, whipsaws, reversals, time-remaining buckets, and volatility regimes.
- Telegram command shell and duplicate-safe transition notifier. `/signal` shows current state and recent window events; `/performance` separates paper fills from missed entries; `/pause` and `/resume` persist notification state. Chat allowlisting fails closed.
- Unauthenticated Polymarket US public REST client and conservative polling fallback. Raw BBO/book payloads are preserved with local receive timestamps, request duration, and change fingerprints. The market-by-slug route follows the official singular `/v1/market/slug/{slug}` endpoint.

## Important limits — not live yet

The user confirmed use of the **Polymarket US app**, not international polymarket.com. The supplied share link identifies `btc-updown-5m-2026-11-26-0250z`; its verified settlement details are stored in `data/contract_btc_updown_5m_2026-11-26-0250z.json`. The official market page states that this contract resolves using CF Benchmarks BRTI: 60 observations are collected during the final minute before each window boundary, averaged, and rounded to $0.01; UP wins when the ending average is greater than or equal to the opening average. The official market API exposes `assetPriceTerms.indexSymbol`, `windowStart`, `windowEnd`, `priceToBeat`, `settlementPrice`, and `priceDecimals`; these fields should be fetched and checked against the market rules before model activation.

- Public REST reads use `https://gateway.polymarket.us` and require no API key. Official documented routes include `/v1/market/slug/{slug}`, `/v1/markets/{slug}/bbo`, `/v1/markets/{slug}/book`, and `/v1/markets/{slug}/settlement`.
- The official market WebSocket at `wss://api.polymarket.us/v1/ws/markets` **requires API-key authentication**. It can stream full books, lite prices, and trades. The SDK bridge is read-only in this project, but requires locally configured `POLYMARKET_KEY_ID` and `POLYMARKET_SECRET_KEY`; never paste them into chat or commit them.
- REST polling is not equivalent to streaming and cannot guarantee second-level updates or detect every short-lived reversal. The poller remains disabled by default; its 2-second interval is an engineering test setting, not a published venue rate limit.
- The user-provided slug and rules are verified from the public page, but the gateway API response, BRTI feed ingestion, WebSocket credentials/permissions, normalized payloads, and end-to-end Telegram delivery have not been integration-tested in this environment.
- BTC spot feeds may be used as explanatory features only. They must not be substituted for the official CF BRTI settlement reference or for its opening `priceToBeat` value.
- No feed coordinator, live Telegram push loop, VPS, or end-to-end deployment is configured.
- Model training, calibration, paper replay, and tests do not establish a profitable edge or realistic fills. Queue position, hidden liquidity, API latency, outages, and actual fees may materially change outcomes.

The share link and market rules are now identified. Run `cd bridge && npm install && npm run inspect -- btc-updown-5m-2026-11-26-0250z` to inspect live public market metadata without credentials. Remaining inputs are local-only setup of an approved Polymarket US API key for the authenticated market WebSocket (if the account is eligible), a timestamped BRTI source/adapter, and Telegram runtime configuration. Do not send account credentials or API secrets.

## Install

Python 3.11+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -e ".[dev]"
cp .env.example .env
```

Set the Telegram token and an explicit chat-ID allowlist in `.env`. Never commit `.env` or paste the token into chat. Public Polymarket US REST reads do not require API keys. Do not generate Retail API keys for this project unless Polymarket confirms a specific approved authenticated read-only feature is needed.

Run tests:

```bash
pytest -q
```

Start the Telegram command bot after installing dependencies and configuring its allowlist:

```bash
fullproof-bot
```

This starts the command interface only. It does **not** connect a market feed or send signals until a coordinator/feed process is deployed.

## Model training and calibration

Use a point-in-time snapshot dataset with a resolved binary target. Each row must contain only information available at that exact timestamp. The default target is `up_win` (1 if the exact market resolved UP, 0 if DOWN).

```bash
fullproof-train --csv data/historical_btc_5m.csv --target up_win --model-path models/btc_up_model.joblib --config config.yaml
```

Required columns include:

- `timestamp` — UTC ISO-8601 timestamp
- `market_id` — exact five-minute contract ID/slug; each market's rows must be contiguous in time
- `btc_price`, `market_open_price`, `volume`, `bid_size`, `ask_size`, `seconds_remaining`
- `up_win` (or the selected target), constant for every row in the same resolved market

Optional fields improve replay and auditability: window open/close, point-in-time candle OHLC, BTC quote age, Polymarket UP/DOWN bid/ask, side-specific ask/bid depth in USD, quote age, momentum, volume z-score, realized volatility, and order-book imbalance.

The training script sorts chronologically, holds out whole later market windows, calibrates on a later whole-market segment than base-model fitting, and uses expanding walk-forward folds. It never uses random train/test splits. It does not use centered rolling windows. Current candle high/low values must be **as observed at the decision timestamp**, not the final high/low of a candle that had not closed yet.

The training report includes calibration metrics and, when the holdout has all required BBO/depth/OHLC fields, a swing-vs-hold-to-expiry replay. If the fields are missing, the report explicitly marks that replay as `not_run`; it does not invent bids, depth, fills, or settlement outcomes.

## Swing replay data requirements

For a meaningful swing-vs-hold comparison, include all of the following in the holdout data:

- `up_bid`, `up_ask`, `down_bid`, `down_ask`
- `up_ask_depth_usd`, `down_ask_depth_usd`, `up_bid_depth_usd`, `down_bid_depth_usd`
- `quote_age_seconds`, `btc_quote_age_seconds`
- `candle_open`, `candle_high`, `candle_low`, `candle_close` (point-in-time values)
- `momentum` or `ret_3`; `volume_zscore` or `volume_z_20`; `volatility` or `realized_vol_12`
- `order_book_imbalance`, `resolved_up`, and model-generated calibrated `p_up`

The baseline takes the first fillable entry that passes the same signal qualification and holds it to official resolution. The swing strategy can close and re-enter; every entry/exit incurs configured fee/slippage assumptions. This is still a snapshot-based paper replay, not a queue-position simulator.

## Risk and signal defaults

- Research bankroll: $2,500
- Maximum hypothetical entry exposure: 1% ($25)
- Daily paper loss stop: 3% ($75)
- Maximum concurrent paper positions: 1 globally
- Minimum calibrated probability: 70%; swing directional thresholds default to 72% UP / 28% DOWN
- Minimum net edge after configured costs: 5 percentage points
- Maximum quote age: 5 seconds; BTC feed age default: 5 seconds
- Minimum displayed top-of-book depth: $100 USD
- Entry window: 15–285 seconds remaining
- Contract price range: $0.05–$0.95
- Two distinct confirming updates by default; identical payloads do not count as separate evidence
- Fee assumption defaults to $0 until the exact applicable fee schedule is confirmed; slippage defaults to $0.01/share for research

These are starting controls, not empirically optimized thresholds. Do not use them for real-money trading.

## Telegram commands

- `/start` — bot scope and commands
- `/status` — feed/model artifact status, current state, remaining time
- `/signal` — current HOLD/continuing/pending state and recent window events
- `/performance` — gross/net paper P&L, open trades, missed/risk-blocked entries, win rate
- `/today` — UTC-day event history
- `/pause` / `/resume` — persistently pause/resume notifications without stopping paper tracking

Only IDs in `TELEGRAM_ALLOWED_CHAT_IDS` receive replies or push alerts. An empty allowlist disables notifications and command replies.

## Polymarket US public REST scaffold

`src/fullproof_crypto/polymarket_us_public.py` contains read-only calls for the documented public market endpoints:

- `GET /v1/markets`
- `GET /v1/market/slug/{slug}`
- `GET /v1/markets/{slug}/bbo`
- `GET /v1/markets/{slug}/book`
- `GET /v1/markets/{slug}/settlement`

`src/fullproof_crypto/public_rest_poller.py` polls a manually verified slug, stores raw JSONL snapshots, and backs off after errors. `market_data_polling.enabled` remains false until live payload normalization and public cadence are verified. The supplied contract slug is stored in `config.yaml`, with the CF BRTI settlement rule and UTC window.

## Files

- `src/fullproof_crypto/model.py` — ensemble and chronological calibration
- `src/fullproof_crypto/train.py` — market-level walk-forward training/evaluation
- `src/fullproof_crypto/backtest.py` — swing-vs-hold replay and transaction-cost accounting
- `src/fullproof_crypto/strategy.py` — multi-swing state machine
- `src/fullproof_crypto/engine.py` — normalized snapshot → event → paper ledger coordinator
- `src/fullproof_crypto/tracker.py` — SQLite events, positions, P&L, notification deduplication
- `src/fullproof_crypto/telegram_bot.py` — allowlisted commands and push formatting
- `src/fullproof_crypto/polymarket_us_public.py` — unauthenticated REST scaffold
- `src/fullproof_crypto/public_rest_poller.py` — REST snapshot polling fallback
- `bridge/` — public market inspector plus optional authenticated, read-only SDK market-data stream; no trading methods

No live market integration or deployment should be claimed until the exact Polymarket US contract, official settlement mapping, BTC reference feed, normalized quote/depth fields, Telegram delivery, and VPS monitoring are verified end to end.
