from datetime import datetime, timezone

from fullproof_crypto.engine import PaperSignalCoordinator
from fullproof_crypto.tracker import SignalTracker


def config():
    return {
        "signals": {
            "max_signal_age_seconds": 5, "min_seconds_remaining": 15,
            "max_seconds_remaining": 285, "min_top_of_book_size_usd": 100,
            "min_contract_price": 0.05, "max_contract_price": 0.95,
            "fee_per_share_usd": 0.0, "slippage_per_share_usd": 0.01,
            "min_probability": 0.70, "min_net_edge": 0.05,
        },
        "risk": {"bankroll_usd": 2500, "max_exposure_fraction_per_signal": 0.01,
                 "daily_loss_stop_fraction": 0.03, "max_open_paper_positions": 1},
        "tracking": {"database_path": ":memory:"},
        "swing": {"entry_up_probability": 0.72, "entry_down_probability": 0.28,
                  "exit_up_below": 0.48, "exit_down_above": 0.52,
                  "entry_confirm_updates": 1, "min_seconds_between_entries": 0,
                  "min_imbalance": 0.05, "min_volume_zscore": -0.5,
                  "max_realized_volatility": 0.01},
    }


def snap(sequence, p, momentum, imbalance, direction="UP"):
    candle = ({"open": 100, "high": 104, "low": 99, "close": 103.5}
              if direction == "UP" else
              {"open": 103.5, "high": 104, "low": 99, "close": 100})
    now = datetime.now(timezone.utc).timestamp() + sequence
    return {
        "market_id": "m1", "source_sequence": sequence,
        "timestamp_epoch": now, "decision_timestamp_epoch": now,
        "feed_timestamp_epoch": now - 0.05, "received_at_epoch": now - 0.02,
        "p_up": p, "probabilities_calibrated": True,
        "seconds_remaining": 180, "quote_age_seconds": 1, "btc_quote_age_seconds": 1,
        "up_ask": 0.60, "down_ask": 0.60, "up_bid": 0.57, "down_bid": 0.57,
        "up_ask_depth_usd": 500, "down_ask_depth_usd": 500,
        "up_bid_depth_usd": 500, "down_bid_depth_usd": 500,
        "momentum": momentum, "order_book_imbalance": imbalance,
        "volume": 100, "volume_zscore": 0.5, "volatility": 0.001,
        "btc_price": 60000, "candle_ohlc": candle,
        "window_open": "2026-11-25T17:00:00Z", "window_close": "2026-11-25T17:05:00Z",
    }


def test_coordinator_records_separate_entry_and_exit_trade(tmp_path):
    cfg = config()
    tracker = SignalTracker(tmp_path / "engine.sqlite3")
    engine = PaperSignalCoordinator(cfg, tracker)

    entry = engine.process_snapshot(snap(1, 0.80, 0.001, 0.30))
    assert entry["event"] == "BUY_UP"
    assert tracker.summary()["open_trades"] == 1
    assert tracker.summary()["missed_entries"] == 0

    exit_event = engine.process_snapshot(snap(2, 0.40, -0.001, -0.30, direction="DOWN"))
    assert exit_event["event"] == "EXIT_UP"
    summary = tracker.summary()
    assert summary["open_trades"] == 0
    assert summary["closed_trades"] == 1
    assert summary["resolved_signals"] == 1


def test_daily_loss_stop_blocks_new_entry(tmp_path):
    cfg = config()
    tracker = SignalTracker(tmp_path / "engine.sqlite3")
    today = datetime.now(timezone.utc).date().isoformat()
    tracker.open_paper_trade({
        "trade_id": "loss", "market_id": "old", "direction": "UP",
        "entry_time": f"{today}T10:00:00Z", "entry_quote": 0.5,
        "assumed_fill": 0.51, "exposure_usd": 250, "fillable": True,
    })
    tracker.close_paper_trade("loss", f"{today}T10:01:00Z", 0.1)
    assert tracker.daily_pnl() < -75
    engine = PaperSignalCoordinator(cfg, tracker)
    assert engine.process_snapshot(snap(1, 0.90, 0.001, 0.30)) is None
    assert tracker.summary()["open_trades"] == 0


def test_restart_restores_active_swing_and_links_exit_to_entry_signal(tmp_path):
    cfg = config()
    tracker = SignalTracker(tmp_path / "engine.sqlite3")
    first_process = PaperSignalCoordinator(cfg, tracker)
    entry = first_process.process_snapshot(snap(1, 0.80, 0.001, 0.30))
    assert entry["event"] == "BUY_UP"

    restarted = PaperSignalCoordinator(cfg, tracker)
    assert restarted.state_machine.current_state("m1") == "BUY_UP"
    exit_event = restarted.process_snapshot(snap(2, 0.40, -0.001, -0.30, direction="DOWN"))
    assert exit_event["event"] == "EXIT_UP"
    assert exit_event["signal_id"] == entry["signal_id"]
    assert tracker.summary()["closed_trades"] == 1

    restarted.resolve_market("m1", True, "2026-11-25T17:05:00Z")
    assert restarted.state_machine.current_state("m1") == "HOLD"
    assert tracker.recent_events("m1", 1)[0]["event"] == "MARKET_RESOLVED"


def test_missed_entry_is_not_treated_as_open_or_blocking_other_market(tmp_path):
    cfg = config()
    cfg["signals"]["min_top_of_book_size_usd"] = 10
    tracker = SignalTracker(tmp_path / "engine.sqlite3")
    engine = PaperSignalCoordinator(cfg, tracker)
    first = snap(1, 0.80, 0.001, 0.30)
    first["up_ask_depth_usd"] = 20
    first["down_ask_depth_usd"] = 20
    event = engine.process_snapshot(first)
    assert event["event"] == "BUY_UP"
    assert event["paper_trade_status"] == "MISSED_ENTRY"
    assert tracker.summary()["open_trades"] == 0
    assert tracker.summary()["missed_entries"] == 1

    second = {**snap(2, 0.80, 0.001, 0.30), "market_id": "m2"}
    next_event = engine.process_snapshot(second)
    assert next_event["event"] == "BUY_UP"
    assert next_event["paper_trade_status"] == "OPEN"
    assert tracker.summary()["open_trades"] == 1


def test_official_resolution_settles_still_open_hypothetical_position(tmp_path):
    cfg = config()
    tracker = SignalTracker(tmp_path / "engine.sqlite3")
    engine = PaperSignalCoordinator(cfg, tracker)
    entry = engine.process_snapshot(snap(1, 0.80, 0.001, 0.30))
    assert entry["event"] == "BUY_UP"
    assert tracker.summary()["open_trades"] == 1
    results = engine.resolve_market("m1", True, "2026-11-25T17:05:00Z")
    assert len(results) == 1
    assert results[0]["net_pnl"] > 0
    assert tracker.summary()["closed_trades"] == 1
    assert engine.state_machine.current_state("m1") == "HOLD"
