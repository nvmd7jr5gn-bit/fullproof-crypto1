from fullproof_crypto.polymarket_us_public import PolymarketUSPublicClient


def test_get_markets_uses_public_gateway_and_no_auth(monkeypatch):
    client = PolymarketUSPublicClient()
    seen = {}

    def fake_get(path, params=None):
        seen["path"] = path
        seen["params"] = params
        return {"markets": []}

    monkeypatch.setattr(client, "_get", fake_get)
    assert client.get_markets(limit=25) == {"markets": []}
    assert seen["path"] == "/v1/markets"
    assert seen["params"]["active"] == "true"
    assert seen["params"]["closed"] == "false"
    assert seen["params"]["limit"] == 25


def test_slug_is_url_encoded_and_bbo_path_is_correct(monkeypatch):
    client = PolymarketUSPublicClient()
    seen = []
    monkeypatch.setattr(client, "_get", lambda path, params=None: seen.append(path) or {})
    client.get_bbo("btc up/down 5m")
    assert seen == ["/v1/markets/btc%20up%2Fdown%205m/bbo"]


def test_invalid_market_query_rejected():
    client = PolymarketUSPublicClient()
    try:
        client.get_markets(limit=0)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid limit should fail")


def test_market_by_slug_uses_documented_singular_route(monkeypatch):
    client = PolymarketUSPublicClient()
    seen = []
    monkeypatch.setattr(client, "_get", lambda path, params=None: seen.append(path) or {"market": {}})
    client.get_market("btc-updown-5m-2026-11-26-0250z")
    assert seen == ["/v1/market/slug/btc-updown-5m-2026-11-26-0250z"]
