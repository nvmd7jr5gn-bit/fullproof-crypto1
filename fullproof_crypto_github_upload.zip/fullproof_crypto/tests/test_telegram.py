import pytest

from fullproof_crypto.telegram_bot import (
    format_current_status,
    format_transition,
    is_authorized_chat,
    notify_transition,
)
from fullproof_crypto.tracker import SignalTracker


def test_authorization_fails_closed(monkeypatch):
    monkeypatch.delenv("TELEGRAM_ALLOWED_CHAT_IDS", raising=False)
    assert is_authorized_chat("123") is False
    monkeypatch.setenv("TELEGRAM_ALLOWED_CHAT_IDS", "123,456")
    assert is_authorized_chat("123") is True
    assert is_authorized_chat("789") is False


def test_transition_labels_distinguish_new_reentry_and_reversal():
    base = {"event": "BUY_UP", "direction": "UP", "p_up": 0.8, "p_down": 0.2,
            "market_id": "m1", "seconds_remaining": 120, "state_before": "HOLD",
            "state_after": "BUY_UP", "reason": "confirmed", "transition_type": "NEW_ENTRY"}
    assert "NEW UP ENTRY" in format_transition(base)
    assert "UP RE-ENTRY" in format_transition({**base, "transition_type": "RE_ENTRY"})
    assert "REVERSAL" in format_transition({**base, "transition_type": "REVERSAL"})


def test_current_status_shows_hold_and_continuing_position():
    assert "HOLD" in format_current_status(None)
    text = format_current_status({"market_id": "m1", "current_state": "BUY_DOWN",
                                  "paper_trade_status": "OPEN", "seconds_remaining": 80,
                                  "p_up": 0.2, "p_down": 0.8})
    assert "POSITION CONTINUES" in text
    missed = format_current_status({"market_id": "m1", "current_state": "BUY_UP",
                                    "paper_trade_status": "MISSED_ENTRY", "seconds_remaining": 80,
                                    "p_up": 0.8})
    assert "ENTRY MISSED" in missed
    assert "80s" in text


@pytest.mark.asyncio
async def test_notification_is_deduplicated_and_latency_recorded(tmp_path, monkeypatch):
    monkeypatch.setenv("TELEGRAM_ALLOWED_CHAT_IDS", "123")
    tracker = SignalTracker(tmp_path / "ledger.sqlite3")

    class FakeMessage:
        message_id = 7

    class FakeBot:
        def __init__(self):
            self.sent = []
            self.edited = []

        async def send_message(self, **kwargs):
            self.sent.append(kwargs)
            return FakeMessage()

        async def edit_message_text(self, **kwargs):
            self.edited.append(kwargs)

    bot = FakeBot()
    event = {"event_id": "e1", "timestamp_epoch": 1800000000.0,
             "event": "BUY_UP", "direction": "UP", "transition_type": "NEW_ENTRY",
             "market_id": "m1", "state_before": "HOLD", "state_after": "BUY_UP",
             "p_up": 0.8, "p_down": 0.2, "seconds_remaining": 120, "reason": "edge"}
    first = await notify_transition(bot, event, tracker)
    second = await notify_transition(bot, event, tracker)
    assert len(first) == 1
    assert second == []
    assert len(bot.sent) == 1
    assert len(bot.edited) == 1
    assert tracker.notification_was_sent("e1", "123") is True


def test_transition_text_distinguishes_fill_miss_and_pending_exit():
    base = {"event": "BUY_DOWN", "direction": "DOWN", "p_up": 0.2, "p_down": 0.8,
            "market_id": "m1", "seconds_remaining": 100, "state_before": "HOLD",
            "state_after": "BUY_DOWN", "reason": "confirmed", "transition_type": "NEW_ENTRY"}
    assert "PAPER POSITION OPEN" in format_transition({**base, "paper_trade_status": "OPEN"})
    assert "ENTRY MISSED" in format_transition({**base, "paper_trade_status": "MISSED_ENTRY"})
    pending = {**base, "event": "DOWN_INVALIDATED", "state_after": "EXIT_PENDING_DOWN"}
    assert "EXIT PENDING" in format_transition(pending)
    no_position = {**pending, "state_after": "HOLD"}
    assert "NO PAPER POSITION" in format_transition(no_position)
