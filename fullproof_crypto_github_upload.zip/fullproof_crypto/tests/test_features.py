import pandas as pd
from fullproof_crypto.features import build_features, FEATURE_COLUMNS

def test_feature_builder_returns_expected_columns():
    n = 40
    df = pd.DataFrame({
        "btc_price": [50000 + i * 5 for i in range(n)],
        "market_open_price": [50000] * n,
        "volume": [10 + i % 4 for i in range(n)],
        "bid_size": [20] * n,
        "ask_size": [15] * n,
        "seconds_remaining": [300 - (i % 300) for i in range(n)],
    })
    out = build_features(df)
    assert set(FEATURE_COLUMNS).issubset(out.columns)
