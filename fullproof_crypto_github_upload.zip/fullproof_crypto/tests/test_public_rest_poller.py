from fullproof_crypto.public_rest_poller import PublicRestPoller


class FakeClient:
    def __init__(self):
        self.bbo_calls = 0
        self.book_calls = 0

    def get_bbo(self, slug):
        self.bbo_calls += 1
        return {"slug": slug, "bid": "0.48", "ask": "0.51"}

    def get_book(self, slug):
        self.book_calls += 1
        return {"slug": slug, "bids": [], "asks": []}


def test_poller_records_timestamp_and_detects_unchanged_payload():
    client = FakeClient()
    times = iter([1_800_000_000.0, 1_800_000_002.0])
    poller = PublicRestPoller(client, "btc-5m", interval_seconds=2, clock=lambda: next(times))
    first = poller.poll_once()
    second = poller.poll_once()
    assert first.observed_at_unix_ms == 1_800_000_000_000
    assert first.changed is True
    assert second.changed is False
    assert client.bbo_calls == 2
    assert client.book_calls == 0


def test_order_book_is_sampled_every_configured_number_of_polls():
    client = FakeClient()
    poller = PublicRestPoller(client, "btc-5m", book_every_n=2)
    poller.poll_once()
    second = poller.poll_once()
    assert second.book == {"slug": "btc-5m", "bids": [], "asks": []}
    assert client.book_calls == 1


def test_poller_rejects_invalid_configuration():
    client = FakeClient()
    for kwargs in ({"interval_seconds": 0}, {"book_every_n": 0}):
        try:
            PublicRestPoller(client, "btc-5m", **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid polling configuration should fail")


def test_book_sampling_does_not_make_unchanged_bbo_look_changed():
    client = FakeClient()
    poller = PublicRestPoller(client, "btc-5m", book_every_n=2)
    first = poller.poll_once()
    second = poller.poll_once()
    third = poller.poll_once()
    assert first.changed is True
    assert second.book_changed is True
    assert second.changed is True
    assert third.bbo_changed is False
    assert third.book_changed is None
    assert third.changed is False
