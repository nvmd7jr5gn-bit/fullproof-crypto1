import pytest
from fullproof_crypto.polymarket_us import PolymarketUSMarketStream, PolymarketUSConfigError


def test_requires_verified_market_slug():
    with pytest.raises(ValueError):
        PolymarketUSMarketStream([])


@pytest.mark.asyncio
async def test_stream_requires_credentials(monkeypatch):
    monkeypatch.delenv('POLYMARKET_KEY_ID', raising=False)
    monkeypatch.delenv('POLYMARKET_SECRET_KEY', raising=False)
    stream = PolymarketUSMarketStream(['verified-us-btc-5m-slug'])
    with pytest.raises(PolymarketUSConfigError):
        async for _ in stream.events():
            pass
