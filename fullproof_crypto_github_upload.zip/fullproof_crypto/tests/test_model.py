import numpy as np
import pandas as pd
import pytest

from fullproof_crypto.features import FEATURE_COLUMNS
from fullproof_crypto.model import QuantProbabilityModel


def make_data(groups=50, rows_per_group=50):
    rng = np.random.default_rng(7)
    n = groups * rows_per_group
    x = pd.DataFrame(rng.normal(size=(n, len(FEATURE_COLUMNS))), columns=FEATURE_COLUMNS)
    group_ids = np.repeat([f"market-{i:03d}" for i in range(groups)], rows_per_group)
    y = np.repeat(np.array([i % 2 for i in range(groups)]), rows_per_group)
    # Add a weak signal to ensure the fit is not degenerate.
    x["ret_1"] += y * 0.2
    return x, y, group_ids


def test_model_calibrates_on_later_whole_markets_and_predicts():
    x, y, groups = make_data()
    model = QuantProbabilityModel().fit(x, y, groups=groups)
    assert model.is_fitted and model.is_calibrated
    assert model.fit_groups_ == 40
    assert model.calibration_groups_ == 10
    assert set(groups[: model.fit_rows_]).isdisjoint(set(groups[model.fit_rows_ :]))
    probabilities = model.predict_proba(x.iloc[-10:])
    assert probabilities.shape == (10, 2)
    assert np.allclose(probabilities.sum(axis=1), 1.0)
    assert np.all((probabilities > 0) & (probabilities < 1))


def test_model_rejects_interleaved_market_groups():
    x, y, groups = make_data(groups=50, rows_per_group=40)
    groups[80] = "market-000"
    with pytest.raises(ValueError, match="contiguous"):
        QuantProbabilityModel().fit(x, y, groups=groups)


def test_model_requires_both_classes_in_calibration_segment():
    x, y, groups = make_data()
    y[-500:] = 0
    with pytest.raises(ValueError, match="both classes"):
        QuantProbabilityModel().fit(x, y, groups=groups)


def test_model_requires_market_groups_and_roundtrips_artifact(tmp_path):
    x, y, groups = make_data()
    with pytest.raises(ValueError, match="market_id groups are required"):
        QuantProbabilityModel().fit(x, y)
    model = QuantProbabilityModel().fit(x, y, groups=groups)
    path = tmp_path / "models" / "model.joblib"
    model.save(path)
    loaded = QuantProbabilityModel.load(path)
    assert loaded.is_calibrated
    assert loaded.predict_proba(x.iloc[:3]).shape == (3, 2)
