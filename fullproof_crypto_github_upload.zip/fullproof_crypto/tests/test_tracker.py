from fullproof_crypto.tracker import SignalTracker


def test_event_dedup_trade_accounting_and_notification_ledger(tmp_path):
    tracker = SignalTracker(tmp_path / "ledger.sqlite3")
    event = {
        "event_id": "e1", "market_id": "m1", "timestamp": "2026-11-25T17:00:01Z",
        "event": "BUY_UP", "state_before": "HOLD", "state_after": "BUY_UP",
    }
    assert tracker.record_event(event) is True
    assert tracker.record_event(event) is False
    status = tracker.open_paper_trade({
        "trade_id": "t1", "market_id": "m1", "signal_id": "s1", "direction": "UP",
        "entry_time": "2026-11-25T17:00:01Z", "entry_quote": 0.50,
        "assumed_fill": 0.51, "exposure_usd": 25, "fillable": True,
        "entry_fees": 0.10, "entry_slippage": 0.49, "entry_event_id": "e1",
    })
    assert status == "OPEN"
    assert tracker.get_open_trade("m1")["shares"] > 0
    result = tracker.close_paper_trade(
        "t1", "2026-11-25T17:01:00Z", 0.60,
        fees_usd=0.10, slippage_usd=0.49, exit_event_id="e2",
    )
    assert result["gross_pnl"] > 0
    assert result["net_pnl"] < result["gross_pnl"]
    assert tracker.get_open_trade("m1") is None

    tracker.record_notification("e1", "123", "2026-11-25T17:00:02Z", 120.0)
    assert tracker.notification_was_sent("e1", "123") is True
    assert tracker.notification_was_sent("e1", "456") is False
    summary = tracker.summary()
    assert summary["closed_trades"] == 1
    assert summary["event_count"] == 1


def test_missed_entry_is_not_counted_as_open_or_filled(tmp_path):
    tracker = SignalTracker(tmp_path / "ledger.sqlite3")
    tracker.open_paper_trade({
        "trade_id": "missed", "market_id": "m1", "direction": "DOWN",
        "entry_time": "2026-11-25T17:00:01Z", "entry_quote": 0.60,
        "assumed_fill": None, "exposure_usd": 25, "fillable": False,
        "fillability_reason": "Ask moved beyond max price",
    })
    summary = tracker.summary()
    assert summary["missed_entries"] == 1
    assert summary["open_trades"] == 0
    assert tracker.get_open_trade("m1") is None


def test_global_position_cap_and_market_state(tmp_path):
    tracker = SignalTracker(tmp_path / "ledger.sqlite3")
    tracker.open_paper_trade({
        "trade_id": "t1", "market_id": "m1", "direction": "UP",
        "entry_time": "2026-11-25T17:00:01Z", "entry_quote": 0.5,
        "assumed_fill": 0.51, "exposure_usd": 25, "fillable": True,
    }, max_open_positions=1)
    assert tracker.can_open_position(max_open_positions=1)[0] is False
    tracker.update_market_state("m1", "2026-11-25T17:00:02Z", "BUY_UP", 180, {"p_up": 0.8})
    latest = tracker.latest_market_state()
    assert latest["current_state"] == "BUY_UP"
    assert abs(latest["p_down"] - 0.2) < 1e-9


def test_official_market_resolution_closes_open_paper_trade(tmp_path):
    tracker = SignalTracker(tmp_path / "ledger.sqlite3")
    tracker.open_paper_trade({
        "trade_id": "t1", "market_id": "m1", "signal_id": "s1", "direction": "UP",
        "entry_time": "2026-11-25T17:00:01Z", "entry_quote": 0.5,
        "assumed_fill": 0.51, "exposure_usd": 25, "fillable": True,
    })
    result = tracker.resolve_market("m1", True, "2026-11-25T17:05:00Z")
    assert len(result) == 1
    assert result[0]["net_pnl"] > 0
    assert tracker.summary()["closed_trades"] == 1


def test_mark_to_market_includes_estimated_exit_costs_and_market_summary(tmp_path):
    tracker = SignalTracker(tmp_path / "ledger.sqlite3")
    tracker.open_paper_trade({
        "trade_id": "t1", "market_id": "m1", "direction": "UP",
        "entry_time": "2026-11-25T17:00:01Z", "entry_quote": 0.50,
        "assumed_fill": 0.51, "exposure_usd": 25, "fillable": True,
        "entry_fees": 0.05, "entry_slippage": 0.50,
    })
    mark = tracker.mark_to_market(
        "m1", 0.55, "2026-11-25T17:00:02Z",
        estimated_exit_fees_usd=0.05, estimated_exit_slippage_usd=0.50,
    )
    assert mark["net_pnl"] < mark["gross_pnl"]
    assert tracker.market_performance("m1")[0]["open"] == 1
