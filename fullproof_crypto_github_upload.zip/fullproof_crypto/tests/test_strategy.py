from fullproof_crypto.strategy import SwingStateMachine, evaluate_signal


def base_cfg():
    return {
        "signals": {
            "max_signal_age_seconds": 5,
            "min_seconds_remaining": 15,
            "max_seconds_remaining": 285,
            "min_top_of_book_size_usd": 100,
            "min_contract_price": 0.05,
            "max_contract_price": 0.95,
            "fee_per_share_usd": 0.0,
            "slippage_per_share_usd": 0.01,
            "min_probability": 0.70,
            "min_net_edge": 0.05,
        },
        "risk": {
            "bankroll_usd": 2500,
            "max_exposure_fraction_per_signal": 0.01,
            "max_open_paper_positions": 1,
        },
        "swing": {
            "entry_up_probability": 0.72,
            "entry_down_probability": 0.28,
            "exit_up_below": 0.48,
            "exit_down_above": 0.52,
            "entry_confirm_updates": 1,
            "min_seconds_between_entries": 0,
            "min_imbalance": 0.05,
            "min_volume_zscore": -0.5,
            "max_realized_volatility": 0.01,
        },
    }


def snap(t, p, momentum, imbalance, *, market="m1", direction="UP", quote_age=1):
    if direction == "UP":
        candle = {"open": 59900, "high": 60200, "low": 59850, "close": 60180}
    else:
        candle = {"open": 60180, "high": 60200, "low": 59850, "close": 59900}
    return {
        "market_id": market,
        "source_sequence": t,
        "timestamp_epoch": float(t),
        "feed_timestamp_epoch": float(t) - 0.05,
        "received_at_epoch": float(t) - 0.02,
        "p_up": p,
        "probabilities_calibrated": True,
        "seconds_remaining": 200,
        "quote_age_seconds": quote_age,
        "btc_quote_age_seconds": 1,
        "top_size_usd": 500,
        "up_ask_depth_usd": 500,
        "down_ask_depth_usd": 500,
        "up_bid_depth_usd": 500,
        "down_bid_depth_usd": 500,
        "up_ask": 0.60,
        "down_ask": 0.60,
        "up_bid": 0.57,
        "down_bid": 0.57,
        "momentum": momentum,
        "volume": 100,
        "volume_zscore": 0.4,
        "volatility": 0.001,
        "order_book_imbalance": imbalance,
        "btc_price": 60000 + t,
        "candle_ohlc": candle,
        "window_open": "2026-11-25T17:00:00Z",
        "window_close": "2026-11-25T17:05:00Z",
    }


def test_qualifies_positive_edge_only_when_calibrated():
    kwargs = dict(
        market_id="test",
        p_up=0.80,
        up_ask=0.70,
        down_ask=0.30,
        seconds_remaining=120,
        quote_age_seconds=1,
        top_size_usd=500,
        cfg=base_cfg(),
        signal_id="s1",
    )
    assert evaluate_signal(**kwargs) is None
    signal = evaluate_signal(**kwargs, probabilities_calibrated=True)
    assert signal is not None
    assert signal.direction == "UP"
    assert signal.exposure_usd == 25


def test_rejects_stale_quote():
    signal = evaluate_signal(
        market_id="test", p_up=0.80, up_ask=0.70, down_ask=0.30,
        seconds_remaining=120, quote_age_seconds=9, top_size_usd=500,
        cfg=base_cfg(), signal_id="s2", probabilities_calibrated=True,
    )
    assert signal is None


def test_multiple_swings_and_reversals_inside_one_window():
    cfg = base_cfg()
    sm = SwingStateMachine(cfg)
    events = [
        sm.update(snap(1, 0.80, 0.001, 0.30, direction="UP")),
        sm.update(snap(2, 0.40, -0.001, -0.30, direction="DOWN")),
        sm.update(snap(3, 0.20, -0.001, -0.30, direction="DOWN")),
        sm.update(snap(4, 0.60, 0.001, 0.30, direction="UP")),
        sm.update(snap(5, 0.80, 0.001, 0.30, direction="UP")),
    ]
    assert [event["event"] for event in events] == [
        "BUY_UP", "EXIT_UP", "BUY_DOWN", "EXIT_DOWN", "BUY_UP"
    ]
    assert events[2]["transition_type"] == "REVERSAL"
    assert events[4]["transition_type"] == "REVERSAL"
    assert abs(events[0]["feed_to_decision_latency_ms"] - 50.0) < 1e-6
    assert events[0]["entry_fillable"] is True
    assert sm.current_state("m1") == "BUY_UP"
    assert len(sm.event_history("m1")) == 5


def test_identical_rest_payload_does_not_satisfy_entry_confirmation():
    cfg = base_cfg()
    cfg["swing"]["entry_confirm_updates"] = 2
    sm = SwingStateMachine(cfg)
    first = snap(1, 0.80, 0.001, 0.30)
    assert sm.update(first) is None
    # Timestamp, remaining time, and a changed transport sequence alone are not
    # a meaningful market update if all market evidence is identical.
    duplicate = {**first, "source_sequence": 999, "timestamp_epoch": 2, "seconds_remaining": 199}
    assert sm.update(duplicate) is None
    changed = {**first, "timestamp_epoch": 3, "btc_price": 60003}
    assert sm.update(changed)["event"] == "BUY_UP"


def test_calibration_candle_volume_and_volatility_are_required_for_entry():
    sm = SwingStateMachine(base_cfg())
    uncalibrated = {**snap(1, 0.90, 0.001, 0.30), "probabilities_calibrated": False}
    assert sm.update(uncalibrated) is None
    no_candle = {**snap(2, 0.90, 0.001, 0.30), "candle_ohlc": None}
    assert sm.update(no_candle) is None
    no_volume = {**snap(3, 0.90, 0.001, 0.30), "volume_zscore": -2}
    assert sm.update(no_volume) is None
    high_vol = {**snap(4, 0.90, 0.001, 0.30), "volatility": 0.02}
    assert sm.update(high_vol) is None


def test_stale_exit_is_pending_until_executable_bid_is_observed():
    sm = SwingStateMachine(base_cfg())
    assert sm.update(snap(1, 0.80, 0.001, 0.30))["event"] == "BUY_UP"
    stale = {**snap(2, 0.80, -0.001, -0.30, direction="DOWN"), "quote_age_seconds": 10}
    event = sm.update(stale)
    assert event["event"] == "UP_INVALIDATED"
    assert event["state_after"] == "EXIT_PENDING_UP"
    assert event["exit_fillable"] is False
    fresh = snap(3, 0.40, -0.001, -0.30, direction="DOWN")
    event = sm.update(fresh)
    assert event["event"] == "EXIT_UP"
    assert event["exit_fillable"] is True
    assert sm.current_state("m1") == "HOLD"


def test_global_open_position_cap_blocks_second_market():
    sm = SwingStateMachine(base_cfg())
    assert sm.update(snap(1, 0.80, 0.001, 0.30, market="m1"))["event"] == "BUY_UP"
    assert sm.update(snap(2, 0.80, 0.001, 0.30, market="m2")) is None
    assert sm.current_state("m2") == "HOLD"


def test_pending_exit_rechecks_newly_received_same_price_snapshot():
    sm = SwingStateMachine(base_cfg())
    entry = snap(1, 0.80, 0.001, 0.30)
    entry.pop("source_sequence")
    assert sm.update(entry)["event"] == "BUY_UP"
    stale = snap(2, 0.80, -0.001, -0.30, direction="DOWN", quote_age=10)
    stale.pop("source_sequence")
    assert sm.update(stale)["event"] == "UP_INVALIDATED"
    fresh = {**stale, "timestamp_epoch": 3, "received_at_epoch": 2.98,
             "decision_timestamp_epoch": 3, "quote_age_seconds": 1,
             "feed_timestamp_epoch": 2.95}
    event = sm.update(fresh)
    assert event["event"] == "EXIT_UP"


def test_nonfillable_entry_signal_does_not_consume_global_position_slot():
    cfg = base_cfg()
    cfg["signals"]["min_top_of_book_size_usd"] = 10
    sm = SwingStateMachine(cfg)
    first = snap(1, 0.80, 0.001, 0.30, market="m1")
    first["up_ask_depth_usd"] = 20
    first["down_ask_depth_usd"] = 20
    event = sm.update(first)
    assert event["event"] == "BUY_UP"
    assert event["entry_fillable"] is False
    assert "m1" not in sm.open_positions
    second = snap(2, 0.80, 0.001, 0.30, market="m2")
    assert sm.update(second)["event"] == "BUY_UP"
    assert "m2" in sm.open_positions
