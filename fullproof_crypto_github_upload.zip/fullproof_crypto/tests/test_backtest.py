import pandas as pd

from fullproof_crypto.backtest import evaluate_swing_vs_hold


def cfg():
    return {
        "signals": {
            "max_signal_age_seconds": 5, "min_seconds_remaining": 15,
            "max_seconds_remaining": 285, "min_top_of_book_size_usd": 100,
            "min_contract_price": 0.05, "max_contract_price": 0.95,
            "fee_per_share_usd": 0.0, "slippage_per_share_usd": 0.01,
            "min_probability": 0.70, "min_net_edge": 0.05,
        },
        "risk": {"bankroll_usd": 2500, "max_exposure_fraction_per_signal": 0.01,
                 "max_open_paper_positions": 1},
        "swing": {"entry_up_probability": 0.72, "entry_down_probability": 0.28,
                  "exit_up_below": 0.48, "exit_down_above": 0.52,
                  "entry_confirm_updates": 1, "min_seconds_between_entries": 0,
                  "min_imbalance": 0.05, "min_volume_zscore": -0.5,
                  "max_realized_volatility": 0.01},
    }


def test_replay_compares_multiple_swings_to_first_entry_hold_baseline():
    rows = []
    states = [
        (0.80, 0.001, 0.30, "up"),
        (0.40, -0.001, -0.30, "down"),
        (0.20, -0.001, -0.30, "down"),
        (0.60, 0.001, 0.30, "up"),
        (0.80, 0.001, 0.30, "up"),
    ]
    for i, (p, momentum, imbalance, candle_dir) in enumerate(states):
        if candle_dir == "up":
            candle = (100, 104, 99, 103.5)
        else:
            candle = (103.5, 104, 99, 100)
        rows.append({
            "timestamp": pd.Timestamp("2026-11-25T17:00:00Z") + pd.Timedelta(seconds=i * 60),
            "market_id": "m1", "seconds_remaining": 240 - i * 60,
            "p_up": p, "probabilities_calibrated": True, "resolved_up": True,
            "up_bid": 0.57, "up_ask": 0.60, "down_bid": 0.57, "down_ask": 0.60,
            "up_ask_depth_usd": 500, "down_ask_depth_usd": 500,
            "up_bid_depth_usd": 500, "down_bid_depth_usd": 500,
            "quote_age_seconds": 1, "btc_price": 60000 + i,
            "volume": 100, "volume_zscore": 0.5, "volatility": 0.001,
            "momentum": momentum, "order_book_imbalance": imbalance,
            "candle_open": candle[0], "candle_high": candle[1],
            "candle_low": candle[2], "candle_close": candle[3],
        })
    result = evaluate_swing_vs_hold(pd.DataFrame(rows), cfg())
    assert result["status"] == "completed"
    assert result["swing_strategy"]["trades"] == 2
    assert result["hold_to_expiry_baseline"]["trades"] == 1
    assert result["swing_strategy"]["net_pnl_usd"] < result["hold_to_expiry_baseline"]["net_pnl_usd"]
    assert result["reversal_events"] == 1
    assert result["swing_strategy"]["net_pnl_usd"] < result["swing_strategy"]["gross_pnl_usd"]


def test_replay_refuses_incomplete_or_uncalibrated_data():
    assert evaluate_swing_vs_hold(pd.DataFrame(), cfg())["status"] == "not_run"
    frame = pd.DataFrame({"timestamp": ["2026-11-25T17:00:00Z"], "market_id": ["m1"]})
    result = evaluate_swing_vs_hold(frame, cfg())
    assert result["status"] == "not_run"
    assert "Missing replay columns" in result["reason"]
