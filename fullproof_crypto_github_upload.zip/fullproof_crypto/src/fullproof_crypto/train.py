from __future__ import annotations

import argparse
import json
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    log_loss,
)

from .backtest import evaluate_swing_vs_hold
from .config import load_config
from .features import FEATURE_COLUMNS, build_features
from .model import QuantProbabilityModel


def _expected_calibration_error(y: np.ndarray, p: np.ndarray, bins: int = 10) -> float:
    edges = np.linspace(0.0, 1.0, bins + 1)
    total = len(y)
    if total == 0:
        return float("nan")
    error = 0.0
    for index in range(bins):
        mask = (p >= edges[index]) & (
            p < edges[index + 1] if index < bins - 1 else p <= edges[index + 1]
        )
        if mask.any():
            error += float(mask.sum() / total) * abs(float(p[mask].mean()) - float(y[mask].mean()))
    return error


def _metrics(y, p) -> dict[str, float]:
    y = np.asarray(y, dtype=int)
    p = np.clip(np.asarray(p, dtype=float), 0.001, 0.999)
    if len(y) == 0 or len(np.unique(y)) < 2:
        raise ValueError("Evaluation segment must contain both outcome classes")
    return {
        "accuracy": float(accuracy_score(y, p >= 0.5)),
        "balanced_accuracy": float(balanced_accuracy_score(y, p >= 0.5)),
        "brier_score": float(brier_score_loss(y, p)),
        "log_loss": float(log_loss(y, p, labels=[0, 1])),
        "expected_calibration_error_10bin": _expected_calibration_error(y, p),
    }


def _chronological_group_split(
    frame: pd.DataFrame, holdout_fraction: float, group_col: str = "market_id"
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Split on whole market IDs, preserving chronological order."""
    if group_col not in frame:
        raise ValueError(f"{group_col} is required for leakage-resistant market-level splits")
    groups = frame[group_col]
    if groups.isna().any():
        raise ValueError(f"{group_col} cannot contain missing values")
    block_ids = groups.ne(groups.shift()).cumsum()
    ordered_groups = groups.groupby(block_ids, sort=False).first().tolist()
    if len(ordered_groups) != len(set(ordered_groups)):
        raise ValueError("Rows for each market_id must be contiguous after chronological sorting")
    if len(ordered_groups) < 5:
        raise ValueError("At least five distinct market windows are required")
    split_group = int(len(ordered_groups) * (1.0 - holdout_fraction))
    split_group = min(max(split_group, 2), len(ordered_groups) - 2)
    train_groups = set(ordered_groups[:split_group])
    train = frame[groups.isin(train_groups)].copy()
    test = frame[~groups.isin(train_groups)].copy()
    if set(train[group_col]).intersection(set(test[group_col])):
        raise AssertionError("Market leakage across chronological split")
    return train.reset_index(drop=True), test.reset_index(drop=True)


def _calibration_buckets(y: np.ndarray, p: np.ndarray) -> dict[str, dict[str, Any]]:
    buckets: dict[str, dict[str, Any]] = {}
    for lo, hi in [(0.0, 0.5), (0.5, 0.6), (0.6, 0.7), (0.7, 0.8), (0.8, 1.0)]:
        mask = (p >= lo) & ((p < hi) if hi < 1.0 else (p <= hi))
        if mask.any():
            buckets[f"{lo:.1f}-{hi:.1f}"] = {
                "count": int(mask.sum()),
                "mean_probability": float(p[mask].mean()),
                "observed_rate": float(y[mask].mean()),
            }
    return buckets


def train(
    csv_path: str, target: str, model_path: str, cfg: dict[str, Any] | None = None
) -> dict[str, Any]:
    raw = pd.read_csv(csv_path, parse_dates=["timestamp"])
    required = {"timestamp", "market_id", target}
    missing = required - set(raw.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    raw = raw.sort_values("timestamp", kind="stable").reset_index(drop=True)
    if raw.timestamp.duplicated().any():
        raise ValueError("Duplicate timestamps: deduplicate snapshots before training")
    numeric_target = pd.to_numeric(raw[target], errors="coerce")
    if numeric_target.isna().any() or not set(numeric_target.unique()).issubset({0, 1}):
        raise ValueError("Target must be complete and exactly binary (0/1)")
    raw[target] = numeric_target.astype(int)
    if raw.groupby("market_id")[target].nunique().gt(1).any():
        raise ValueError("A resolved market_id must have one consistent target value")

    # All features are causal: current/past observations only. No centered windows or
    # future candle fields are used. Missing early rolling features are imputed by model.
    data = build_features(raw).dropna(subset=[target, "timestamp", "market_id"]).reset_index(drop=True)
    if len(data) < 2500:
        raise ValueError(f"Only {len(data)} usable rows; need at least 2,500")

    train_df, holdout_df = _chronological_group_split(data, 0.20)
    model = QuantProbabilityModel().fit(
        train_df[FEATURE_COLUMNS],
        train_df[target].astype(int),
        groups=train_df["market_id"],
    )
    holdout_p = model.predict_proba(holdout_df[FEATURE_COLUMNS])[:, 1]
    holdout_y = holdout_df[target].astype(int).to_numpy()
    metrics: dict[str, Any] = {
        "total_rows": int(len(data)),
        "training_rows_including_calibration": int(len(train_df)),
        "base_fit_rows": model.fit_rows_,
        "calibration_rows": model.calibration_rows_,
        "base_fit_markets": model.fit_groups_,
        "calibration_markets": model.calibration_groups_,
        "holdout_rows": int(len(holdout_df)),
        "holdout_markets": int(holdout_df.market_id.nunique()),
        **_metrics(holdout_y, holdout_p),
        "calibration_by_bucket": _calibration_buckets(holdout_y, holdout_p),
    }

    # Expanding walk-forward folds. Each test block contains unseen whole markets;
    # each fold's internal calibrator also sees only later markets than its base fit.
    groups = data.market_id.drop_duplicates().tolist()
    folds: list[dict[str, Any]] = []
    start = max(5, int(len(groups) * 0.50))
    step = max(2, int(len(groups) * 0.10))
    holdout_group_set = set(holdout_df.market_id)
    pre_holdout = data[~data.market_id.isin(holdout_group_set)].reset_index(drop=True)
    pre_groups = pre_holdout.market_id.drop_duplicates().tolist()
    for end in range(start, len(pre_groups) - 1, step):
        test_group_ids = set(pre_groups[end : min(end + step, len(pre_groups))])
        if not test_group_ids:
            continue
        fold_train = pre_holdout[pre_holdout.market_id.isin(pre_groups[:end])].reset_index(drop=True)
        fold_test = pre_holdout[pre_holdout.market_id.isin(test_group_ids)].reset_index(drop=True)
        if len(fold_train) < 2000 or fold_test.market_id.nunique() < 1:
            continue
        try:
            fold_model = QuantProbabilityModel().fit(
                fold_train[FEATURE_COLUMNS],
                fold_train[target].astype(int),
                groups=fold_train.market_id,
            )
            fold_p = fold_model.predict_proba(fold_test[FEATURE_COLUMNS])[:, 1]
            fold_y = fold_test[target].astype(int).to_numpy()
            folds.append(
                {
                    "train_through_market": str(pre_groups[end - 1]),
                    "test_markets": int(fold_test.market_id.nunique()),
                    "test_rows": int(len(fold_test)),
                    **_metrics(fold_y, fold_p),
                }
            )
        except ValueError as exc:
            folds.append({"skipped": str(exc), "train_through_market": str(pre_groups[end - 1])})
    metrics["walk_forward_folds"] = folds
    try:
        strategy_cfg = cfg if cfg is not None else load_config()
        replay_frame = holdout_df.copy()
        replay_frame["p_up"] = holdout_p
        replay_frame["probabilities_calibrated"] = True
        replay_frame["resolved_up"] = holdout_y
        metrics["swing_vs_hold_baseline"] = evaluate_swing_vs_hold(replay_frame, strategy_cfg)
    except (FileNotFoundError, KeyError, ValueError) as exc:
        metrics["swing_vs_hold_baseline"] = {
            "status": "not_run",
            "reason": f"Replay configuration or required columns unavailable: {exc}",
        }
    metrics["warning"] = (
        "Research-only chronological market-level evaluation. It does not establish live edge, "
        "executable fills, or profitability after actual venue costs."
    )
    model.save(model_path)
    print(json.dumps(metrics, indent=2))
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--target", default="up_win")
    parser.add_argument("--model-path", default="models/btc_up_model.joblib")
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()
    strategy_cfg = load_config(args.config)
    train(args.csv, args.target, args.model_path, strategy_cfg)


if __name__ == "__main__":
    main()
