from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

from .strategy import SwingStateMachine


REQUIRED_COLUMNS = {
    "timestamp", "market_id", "seconds_remaining", "p_up", "resolved_up",
    "up_bid", "up_ask", "down_bid", "down_ask", "quote_age_seconds",
    "btc_price", "volume", "order_book_imbalance",
}


def _timestamp_epoch(value: Any) -> float:
    return pd.Timestamp(value).timestamp()


def _as_float(row: pd.Series, key: str, default: float = 0.0) -> float:
    value = row.get(key, default)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if np.isfinite(number) else default


def _trade_pnl(position: dict[str, Any], payout_or_bid: float, *, exit_trade: bool, cfg: dict[str, Any]) -> dict[str, float]:
    signals = cfg["signals"]
    shares = position["shares"]
    gross = shares * (float(payout_or_bid) - position["entry_quote"])
    fee = float(signals.get("fee_per_share_usd", 0.0))
    slip = float(signals.get("slippage_per_share_usd", 0.0))
    fees = position["entry_fees"] + (shares * fee if exit_trade else 0.0)
    slippage = position["entry_slippage"] + (shares * slip if exit_trade else 0.0)
    return {"gross_pnl": gross, "net_pnl": gross - fees - slippage, "fees": fees, "slippage": slippage}


def _summarize_trades(trades: list[dict[str, Any]], whipsaw_seconds: float) -> dict[str, Any]:
    if not trades:
        return {
            "trades": 0, "wins": 0, "win_rate": 0.0, "gross_pnl_usd": 0.0,
            "net_pnl_usd": 0.0, "max_drawdown_usd": 0.0,
            "longest_losing_streak": 0, "whipsaw_count": 0, "whipsaw_rate": 0.0,
        }
    ordered = sorted(trades, key=lambda item: item["exit_time"])
    pnls = [float(item["net_pnl"]) for item in ordered]
    cumulative = np.cumsum(pnls)
    peaks = np.maximum.accumulate(np.concatenate(([0.0], cumulative)))[1:]
    drawdowns = peaks - cumulative
    losing_streak = longest = 0
    for pnl in pnls:
        losing_streak = losing_streak + 1 if pnl < 0 else 0
        longest = max(longest, losing_streak)
    whipsaws = sum(
        1 for trade in ordered
        if trade.get("holding_seconds") is not None
        and trade["holding_seconds"] <= whipsaw_seconds
        and trade["net_pnl"] < 0
    )
    return {
        "trades": len(ordered),
        "wins": sum(pnl > 0 for pnl in pnls),
        "win_rate": sum(pnl > 0 for pnl in pnls) / len(pnls),
        "gross_pnl_usd": float(sum(item["gross_pnl"] for item in ordered)),
        "net_pnl_usd": float(sum(pnls)),
        "max_drawdown_usd": float(drawdowns.max(initial=0.0)),
        "longest_losing_streak": int(longest),
        "whipsaw_count": int(whipsaws),
        "whipsaw_rate": float(whipsaws / len(ordered)),
    }


def _group_performance(trades: list[dict[str, Any]], key_fn) -> dict[str, Any]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for trade in trades:
        groups[str(key_fn(trade))].append(trade)
    return {
        key: {
            "trades": len(items),
            "net_pnl_usd": float(sum(item["net_pnl"] for item in items)),
            "win_rate": float(sum(item["net_pnl"] > 0 for item in items) / len(items)),
        }
        for key, items in sorted(groups.items())
    }


def evaluate_swing_vs_hold(
    frame: pd.DataFrame,
    cfg: dict[str, Any],
    *,
    whipsaw_seconds: float = 10.0,
) -> dict[str, Any]:
    """Replay calibrated point-in-time holdout snapshots and compare swing vs hold.

    The hold-to-expiry baseline takes the first fillable entry emitted by the same
    qualification engine and keeps it through official binary resolution. Swing
    trades can exit/re-enter and pay both entry and exit costs. This is a research
    comparison, not a substitute for actual queue-position/fill simulation.
    """
    missing = REQUIRED_COLUMNS - set(frame.columns)
    if missing:
        return {"status": "not_run", "reason": f"Missing replay columns: {sorted(missing)}"}
    data = frame.copy()
    if data.empty:
        return {"status": "not_run", "reason": "Replay dataset is empty"}
    data["market_id"] = data["market_id"].astype(str)
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True)
    data = data.sort_values("timestamp", kind="stable").reset_index(drop=True)
    if data["market_id"].isna().any() or data["resolved_up"].isna().any():
        return {"status": "not_run", "reason": "market_id/resolved_up contains missing values"}
    if data.groupby("market_id")["resolved_up"].nunique().gt(1).any():
        return {"status": "not_run", "reason": "resolved_up is inconsistent within a market"}
    calibrated_flags = data.get("probabilities_calibrated", pd.Series(False, index=data.index))
    if calibrated_flags.isna().any() or not calibrated_flags.eq(True).all():
        return {"status": "not_run", "reason": "Replay probabilities must be explicitly marked calibrated"}
    probability_values = pd.to_numeric(data["p_up"], errors="coerce")
    if probability_values.isna().any() or not probability_values.between(0.0, 1.0).all():
        return {"status": "not_run", "reason": "p_up must contain finite probabilities from 0 to 1"}
    resolved_values = pd.to_numeric(data["resolved_up"], errors="coerce")
    if resolved_values.isna().any() or not set(resolved_values.unique()).issubset({0, 1}):
        return {"status": "not_run", "reason": "resolved_up must be binary 0/1"}
    data["resolved_up"] = resolved_values.astype(int)

    # Side-specific ask depth and executable bid depth are required; a generic
    # top_size_usd fallback is not accepted for exit simulation.
    depth_columns = {"up_ask_depth_usd", "down_ask_depth_usd", "up_bid_depth_usd", "down_bid_depth_usd"}
    if not depth_columns.issubset(data.columns):
        return {"status": "not_run", "reason": f"Missing side-specific depth columns: {sorted(depth_columns - set(data.columns))}"}
    candle_sets = [
        {"candle_open", "candle_high", "candle_low", "candle_close"},
        {"open", "high", "low", "close"},
    ]
    candle_cols = next((cols for cols in candle_sets if cols.issubset(data.columns)), None)
    if candle_cols is None and "candle_ohlc" not in data.columns:
        return {"status": "not_run", "reason": "Missing point-in-time candle OHLC columns"}
    if not {"momentum", "ret_3"}.intersection(data.columns):
        return {"status": "not_run", "reason": "Missing momentum/ret_3 column"}
    if not {"volume_zscore", "volume_z_20"}.intersection(data.columns):
        return {"status": "not_run", "reason": "Missing rolling volume z-score column"}
    if not {"volatility", "realized_vol_12"}.intersection(data.columns):
        return {"status": "not_run", "reason": "Missing realized volatility column"}

    state_machine = SwingStateMachine(cfg)
    swing_trades: list[dict[str, Any]] = []
    hold_trades: list[dict[str, Any]] = []
    open_swing: dict[str, dict[str, Any]] = {}
    open_hold: dict[str, dict[str, Any]] = {}
    outcomes = data.groupby("market_id", sort=False)["resolved_up"].first().astype(bool).to_dict()
    close_times: dict[str, float] = {}
    for market_id, rows in data.groupby("market_id", sort=False):
        first = rows.iloc[0]
        if "window_close" in rows and pd.notna(rows["window_close"].iloc[0]):
            close_times[market_id] = _timestamp_epoch(rows["window_close"].iloc[0])
        else:
            close_times[market_id] = _timestamp_epoch(first["timestamp"]) + max(
                0.0, _as_float(first, "seconds_remaining", 300.0)
            )

    def settle_market(market_id: str, exit_epoch: float) -> None:
        resolved_up = bool(outcomes[market_id])
        payout_by_direction = {"UP": 1.0 if resolved_up else 0.0, "DOWN": 0.0 if resolved_up else 1.0}
        for collection, positions, exit_trade in (
            (swing_trades, open_swing, False),
            (hold_trades, open_hold, False),
        ):
            position = positions.pop(market_id, None)
            if position is None:
                continue
            pnl = _trade_pnl(position, payout_by_direction[position["direction"]], exit_trade=exit_trade, cfg=cfg)
            collection.append({
                **position,
                **pnl,
                "exit_time": exit_epoch,
                "holding_seconds": max(0.0, exit_epoch - position["entry_epoch"]),
                "exit_type": "SETTLEMENT",
            })
        state_machine.settle_market(market_id)

    reversals = 0
    missed_entries = 0
    for index, row in data.iterrows():
        now = _timestamp_epoch(row["timestamp"])
        # Settle any expired markets before evaluating a later market snapshot.
        for active_market, close_epoch in list(close_times.items()):
            if close_epoch <= now and (active_market in open_swing or active_market in open_hold or active_market in state_machine.open_positions):
                settle_market(active_market, close_epoch)

        market_id = str(row["market_id"])
        if candle_cols:
            candle = {
                "open": _as_float(row, next(col for col in candle_cols if col.endswith("open"))),
                "high": _as_float(row, next(col for col in candle_cols if col.endswith("high"))),
                "low": _as_float(row, next(col for col in candle_cols if col.endswith("low"))),
                "close": _as_float(row, next(col for col in candle_cols if col.endswith("close"))),
            }
        else:
            candle_value = row.get("candle_ohlc")
            candle = json.loads(candle_value) if isinstance(candle_value, str) else candle_value
        snapshot = {
            "market_id": market_id,
            "timestamp_epoch": now,
            "decision_timestamp_epoch": now,
            "p_up": _as_float(row, "p_up", 0.5),
            "probabilities_calibrated": True,
            "seconds_remaining": int(_as_float(row, "seconds_remaining", 0)),
            "quote_age_seconds": _as_float(row, "quote_age_seconds", 999.0),
            "btc_quote_age_seconds": _as_float(row, "btc_quote_age_seconds", _as_float(row, "quote_age_seconds", 999.0)),
            "btc_price": _as_float(row, "btc_price"),
            "candle_ohlc": candle,
            "momentum": _as_float(row, "momentum", _as_float(row, "ret_3")),
            "ret_1": row.get("ret_1"), "ret_3": row.get("ret_3"), "ret_6": row.get("ret_6"),
            "volume": _as_float(row, "volume"),
            "volume_zscore": _as_float(row, "volume_zscore", _as_float(row, "volume_z_20", float("nan"))),
            "volatility": _as_float(row, "volatility", _as_float(row, "realized_vol_12", float("nan"))),
            "order_book_imbalance": _as_float(row, "order_book_imbalance"),
            "up_bid": _as_float(row, "up_bid", float("nan")),
            "up_ask": _as_float(row, "up_ask", float("nan")),
            "down_bid": _as_float(row, "down_bid", float("nan")),
            "down_ask": _as_float(row, "down_ask", float("nan")),
            "up_ask_depth_usd": _as_float(row, "up_ask_depth_usd"),
            "down_ask_depth_usd": _as_float(row, "down_ask_depth_usd"),
            "up_bid_depth_usd": _as_float(row, "up_bid_depth_usd"),
            "down_bid_depth_usd": _as_float(row, "down_bid_depth_usd"),
            "window_open": row.get("window_open"),
            "window_close": row.get("window_close"),
        }
        event = state_machine.update(snapshot)
        if event:
            if event.get("transition_type") == "REVERSAL":
                reversals += 1
            if event["event"].startswith("BUY_"):
                if not event.get("entry_fillable"):
                    missed_entries += 1
                else:
                    direction = event["direction"]
                    ask = float(event["entry_ask"])
                    slip = float(cfg["signals"].get("slippage_per_share_usd", 0.0))
                    assumed_fill = ask + slip
                    max_entry = float(event["max_entry_price"])
                    fee_per_share = float(cfg["signals"].get("fee_per_share_usd", 0.0))
                    if ask <= max_entry and assumed_fill + fee_per_share > 0:
                        exposure = float(event["exposure_usd"])
                        shares = exposure / (assumed_fill + fee_per_share)
                        position = {
                            "market_id": market_id,
                            "direction": direction,
                            "entry_epoch": now,
                            "entry_seconds_remaining": int(event["seconds_remaining"]),
                            "entry_quote": ask,
                            "assumed_fill": assumed_fill,
                            "shares": shares,
                            "exposure_usd": exposure,
                            "entry_fees": shares * float(cfg["signals"].get("fee_per_share_usd", 0.0)),
                            "entry_slippage": shares * slip,
                            "volatility": snapshot["volatility"],
                            "entry_net_edge": float(event["net_edge"]),
                        }
                        open_swing[market_id] = dict(position)
                        max_positions = max(1, int(cfg["risk"].get("max_open_paper_positions", 1)))
                        if market_id not in open_hold and len(open_hold) < max_positions:
                            open_hold[market_id] = dict(position)
                    else:
                        missed_entries += 1
            elif event["event"] in ("EXIT_UP", "EXIT_DOWN") and event.get("exit_fillable"):
                position = open_swing.pop(market_id, None)
                if position:
                    bid = float(event["exit_bid"])
                    pnl = _trade_pnl(position, bid, exit_trade=True, cfg=cfg)
                    swing_trades.append({
                        **position,
                        **pnl,
                        "exit_time": now,
                        "holding_seconds": max(0.0, now - position["entry_epoch"]),
                        "exit_type": "SWING_EXIT",
                    })
        if int(snapshot["seconds_remaining"]) <= 0:
            settle_market(market_id, now)

    for market_id in set(open_swing) | set(open_hold) | set(state_machine.open_positions):
        settle_market(market_id, close_times.get(market_id, now if len(data) else 0.0))

    swing_summary = _summarize_trades(swing_trades, whipsaw_seconds)
    hold_summary = _summarize_trades(hold_trades, whipsaw_seconds)
    volatility_values = [float(item["volatility"]) for item in swing_trades if np.isfinite(item["volatility"])]
    if volatility_values:
        q1, q2 = np.quantile(volatility_values, [1 / 3, 2 / 3])
        def regime(item):
            value = float(item["volatility"])
            return "LOW" if value <= q1 else "MID" if value <= q2 else "HIGH"
        by_volatility = _group_performance(swing_trades, regime)
    else:
        by_volatility = {}

    return {
        "status": "completed",
        "swing_strategy": swing_summary,
        "hold_to_expiry_baseline": hold_summary,
        "net_pnl_difference_vs_hold_usd": swing_summary["net_pnl_usd"] - hold_summary["net_pnl_usd"],
        "reversal_events": reversals,
        "missed_entries": missed_entries,
        "swing_performance_by_market": _group_performance(swing_trades, lambda item: item["market_id"]),
        "hold_baseline_performance_by_market": _group_performance(hold_trades, lambda item: item["market_id"]),
        "swing_performance_by_entry_time_remaining": _group_performance(
            swing_trades,
            lambda item: (
                "0-30s" if item["entry_seconds_remaining"] <= 30 else
                "31-60s" if item["entry_seconds_remaining"] <= 60 else
                "61-120s" if item["entry_seconds_remaining"] <= 120 else
                "121-180s" if item["entry_seconds_remaining"] <= 180 else "181-300s"
            ),
        ),
        "swing_performance_by_volatility_regime": by_volatility,
        "reversal_detection_delay": "not measurable without independently labeled turning points",
        "warning": (
            "Research replay uses displayed BBO/depth snapshots and configured costs. It cannot model queue position, "
            "hidden liquidity, missed network updates, or guarantee actual fills. The baseline uses the first same-qualified "
            "entry and holds to official resolved_up; swing trades pay costs on every entry and exit."
        ),
    }
