"""Read-only Polymarket US WebSocket adapter via the official TypeScript SDK bridge.

This module never exposes order placement, cancellation, or account mutation methods.
It streams marketData/trade events only. A verified market slug must be supplied by
market discovery after checking the contract's exact resolution rules.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import AsyncIterator, Any


class PolymarketUSConfigError(RuntimeError):
    pass


class PolymarketUSMarketStream:
    def __init__(self, market_slugs: list[str], bridge_dir: str | Path | None = None):
        self.market_slugs = [s.strip() for s in market_slugs if s and s.strip()]
        if not self.market_slugs:
            raise ValueError("At least one verified Polymarket US market slug is required.")
        self.bridge_dir = Path(bridge_dir) if bridge_dir else Path(__file__).resolve().parents[2] / "bridge"
        self.proc: asyncio.subprocess.Process | None = None

    async def events(self) -> AsyncIterator[dict[str, Any]]:
        if not os.getenv("POLYMARKET_KEY_ID") or not os.getenv("POLYMARKET_SECRET_KEY"):
            raise PolymarketUSConfigError(
                "Set POLYMARKET_KEY_ID and POLYMARKET_SECRET_KEY in the server environment. "
                "Never paste credentials into chat or commit them to source control."
            )
        script = self.bridge_dir / "market_stream.mjs"
        if not script.exists():
            raise FileNotFoundError(f"Polymarket US bridge not found: {script}")
        self.proc = await asyncio.create_subprocess_exec(
            "node", str(script), ",".join(self.market_slugs),
            cwd=str(self.bridge_dir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=os.environ.copy(),
        )
        assert self.proc.stdout is not None
        try:
            while line := await self.proc.stdout.readline():
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    continue
        finally:
            await self.close()

    async def close(self) -> None:
        if self.proc and self.proc.returncode is None:
            self.proc.terminate()
            try:
                await asyncio.wait_for(self.proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                self.proc.kill()
                await self.proc.wait()
        self.proc = None
