from pathlib import Path
import os
import yaml
from dotenv import load_dotenv

load_dotenv()

def load_config(path: str = "config.yaml") -> dict:
    with Path(path).open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cfg["tracking"]["database_path"] = os.getenv(
        "FULLPROOF_DB_PATH", cfg["tracking"]["database_path"]
    )
    cfg["model"]["path"] = os.getenv("FULLPROOF_MODEL_PATH", cfg["model"]["path"])
    return cfg
