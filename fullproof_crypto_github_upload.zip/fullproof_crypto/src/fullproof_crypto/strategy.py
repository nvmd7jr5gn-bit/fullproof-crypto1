from __future__ import annotations

import hashlib
import json
import math
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Optional


def _utc_iso(epoch: float | None = None) -> str:
    dt = datetime.now(timezone.utc) if epoch is None else datetime.fromtimestamp(epoch, timezone.utc)
    return dt.isoformat(timespec="milliseconds")


def _finite(value: Any, default: float = float("nan")) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default


@dataclass
class Signal:
    signal_id: str
    timestamp: str
    market_id: str
    direction: str
    probability: float
    entry_ask: float
    net_edge: float
    max_entry_price: float
    exposure_usd: float
    seconds_remaining: int
    status: str = "ALERTED_NOT_FILLED"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def evaluate_signal(
    *,
    market_id: str,
    p_up: float,
    up_ask: float,
    down_ask: float,
    seconds_remaining: int,
    quote_age_seconds: float,
    top_size_usd: float,
    cfg: dict[str, Any],
    signal_id: str,
    probabilities_calibrated: bool = False,
) -> Signal | None:
    """Single-snapshot qualification helper; no fill is assumed."""
    signals_cfg, risk_cfg = cfg["signals"], cfg["risk"]
    if not probabilities_calibrated:
        return None
    numeric = [p_up, up_ask, down_ask, quote_age_seconds, top_size_usd]
    try:
        numeric = [float(value) for value in numeric]
    except (TypeError, ValueError):
        return None
    if not all(math.isfinite(value) for value in numeric):
        return None
    p_up, up_ask, down_ask, quote_age_seconds, top_size_usd = numeric
    if not 0.0 <= p_up <= 1.0 or quote_age_seconds < 0.0 or top_size_usd < 0.0:
        return None
    if not 0.0 <= up_ask <= 1.0 or not 0.0 <= down_ask <= 1.0:
        return None
    if (
        quote_age_seconds > signals_cfg["max_signal_age_seconds"]
        or not signals_cfg["min_seconds_remaining"]
        <= seconds_remaining
        <= signals_cfg["max_seconds_remaining"]
        or top_size_usd < signals_cfg["min_top_of_book_size_usd"]
    ):
        return None

    choices = [("UP", float(p_up), float(up_ask)), ("DOWN", 1.0 - float(p_up), float(down_ask))]
    choices = [
        choice
        for choice in choices
        if signals_cfg["min_contract_price"] <= choice[2] <= signals_cfg["max_contract_price"]
    ]
    if not choices:
        return None
    direction, probability, ask = max(choices, key=lambda item: item[1] - item[2])
    costs = float(signals_cfg["fee_per_share_usd"]) + float(
        signals_cfg.get("slippage_per_share_usd", 0.0)
    )
    edge = probability - ask - costs
    max_entry = probability - costs - float(signals_cfg["min_net_edge"])
    if probability < signals_cfg["min_probability"] or edge < signals_cfg["min_net_edge"]:
        return None

    exposure = float(risk_cfg["bankroll_usd"]) * float(
        risk_cfg["max_exposure_fraction_per_signal"]
    )
    return Signal(
        signal_id=signal_id,
        timestamp=_utc_iso(),
        market_id=market_id,
        direction=direction,
        probability=probability,
        entry_ask=ask,
        net_edge=edge,
        max_entry_price=max_entry,
        exposure_usd=exposure,
        seconds_remaining=int(seconds_remaining),
    )


class SwingStateMachine:
    """Continuous per-market swing state machine with global paper-position caps.

    Call `update` for each *meaningful* market/BTC snapshot. Identical REST payloads
    are deduplicated and cannot satisfy consecutive-entry confirmation by themselves.
    Entries require calibrated probabilities plus candle, momentum, volume, volatility,
    book, price, liquidity, and net-edge evidence. Invalidation can occur faster than
    entry confirmation; if no executable exit quote exists, the state becomes pending
    rather than pretending the paper position was closed.
    """

    _SIGNATURE_FIELDS = (
        "market_id",
        "p_up",
        "probabilities_calibrated",
        "btc_price",
        "candle_ohlc",
        "momentum",
        "ret_1",
        "ret_3",
        "ret_6",
        "volume",
        "volume_zscore",
        "volatility",
        "order_book_imbalance",
        "up_bid",
        "up_ask",
        "down_bid",
        "down_ask",
        "up_ask_depth_usd",
        "down_ask_depth_usd",
        "up_bid_depth_usd",
        "down_bid_depth_usd",
        "last_trade_price",
        "last_trade_size",
        "trade_volume",
        "trade_side",
    )

    def __init__(self, cfg: dict[str, Any]):
        self.cfg = cfg
        self.states: dict[str, str] = {}
        self.confirmations: dict[str, list[str]] = {}
        self.last_entry_epoch: dict[str, float] = {}
        self.last_snapshot_signature: dict[str, str] = {}
        self.last_snapshot_epoch: dict[str, float] = {}
        self.entry_counts: dict[str, int] = {}
        self.active_signal_id: dict[str, str] = {}
        self.last_exit_direction: dict[str, str] = {}
        self.pending_exit: dict[str, str] = {}
        self.open_positions: dict[str, str] = {}
        self.history: dict[str, list[dict[str, Any]]] = {}

    def current_state(self, market_id: str) -> str:
        return self.states.get(str(market_id), "HOLD")

    def restore_open_position(
        self,
        market_id: str,
        direction: str,
        signal_id: str | None = None,
        pending_exit: bool = False,
        occupies_position: bool = True,
    ) -> None:
        """Restore a persisted directional state after a process restart."""
        market_id = str(market_id)
        direction = str(direction).upper()
        if direction not in {"UP", "DOWN"}:
            raise ValueError("direction must be UP or DOWN")
        self.states[market_id] = f"EXIT_PENDING_{direction}" if pending_exit else f"BUY_{direction}"
        if occupies_position:
            self.open_positions[market_id] = direction
        if signal_id:
            self.active_signal_id[market_id] = signal_id
        if pending_exit and occupies_position:
            self.pending_exit[market_id] = direction

    def mark_entry_unfilled(self, market_id: str) -> None:
        """Keep the directional signal state but release hypothetical exposure capacity."""
        self.open_positions.pop(str(market_id), None)

    def event_history(self, market_id: str, limit: int = 20) -> list[dict[str, Any]]:
        return list(self.history.get(str(market_id), [])[-limit:])

    def settle_market(self, market_id: str) -> None:
        """Release the market's signal-state slot after verified binary settlement."""
        market_id = str(market_id)
        self.open_positions.pop(market_id, None)
        self.pending_exit.pop(market_id, None)
        self.confirmations.pop(market_id, None)
        self.states[market_id] = "HOLD"
        self.active_signal_id.pop(market_id, None)

    def _signature(self, snap: dict[str, Any]) -> str:
        material = {key: snap.get(key) for key in self._SIGNATURE_FIELDS}
        # A pending exit must re-check a newly received quote even if the displayed
        # price/depth is unchanged; ordinary entry confirmation still ignores
        # unchanged REST polls so polling cadence cannot manufacture confirmations.
        if str(snap.get("market_id")) in self.pending_exit:
            material["received_at_epoch"] = snap.get("received_at_epoch")
        value = json.dumps(material, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    @staticmethod
    def _candle_evidence(candle: Any, direction: str, cfg: dict[str, Any]) -> bool:
        if not isinstance(candle, dict):
            return False
        o = _finite(candle.get("open"))
        h = _finite(candle.get("high"))
        low = _finite(candle.get("low"))
        close = _finite(candle.get("close"))
        if not all(math.isfinite(value) for value in (o, h, low, close)) or h <= low:
            return False
        body_fraction = (close - o) / (h - low)
        close_location = (close - low) / (h - low)
        min_body = float(cfg.get("min_candle_body_fraction", 0.08))
        if direction == "UP":
            return body_fraction >= min_body and close_location >= float(
                cfg.get("up_close_location_min", 0.55)
            )
        return body_fraction <= -min_body and close_location <= float(
            cfg.get("down_close_location_max", 0.45)
        )

    def _emit(
        self,
        snap: dict[str, Any],
        *,
        event_type: str,
        state_before: str,
        state_after: str,
        direction: str | None,
        reason: str,
        decision_epoch: float,
        values: dict[str, Any],
    ) -> dict[str, Any]:
        market_id = str(snap["market_id"])
        rem = max(0, int(_finite(snap.get("seconds_remaining"), 0)))
        feed_epoch = _finite(snap.get("feed_timestamp_epoch"))
        receive_epoch = _finite(snap.get("received_at_epoch"))
        feed_to_decision = (
            max(0.0, (decision_epoch - feed_epoch) * 1000.0)
            if math.isfinite(feed_epoch)
            else None
        )
        decision_to_feed_receive = (
            max(0.0, (receive_epoch - feed_epoch) * 1000.0)
            if math.isfinite(feed_epoch) and math.isfinite(receive_epoch)
            else None
        )
        p_up = _finite(snap.get("p_up"), 0.5)
        event_id = str(uuid.uuid4())
        event = {
            "event_id": event_id,
            "signal_id": (
                event_id
                if event_type.startswith("BUY_")
                else self.active_signal_id.get(market_id) or snap.get("signal_id") or event_id
            ),
            "market_id": market_id,
            "window_open": snap.get("window_open"),
            "window_close": snap.get("window_close"),
            "timestamp": _utc_iso(decision_epoch),
            "timestamp_epoch": decision_epoch,
            "elapsed_seconds": max(0, int(_finite(snap.get("elapsed_seconds"), 300 - rem))),
            "seconds_remaining": rem,
            "btc_price": snap.get("btc_price"),
            "candle_ohlc": snap.get("candle_ohlc"),
            "short_returns": snap.get(
                "short_returns",
                {key: snap.get(key) for key in ("ret_1", "ret_3", "ret_6")},
            ),
            "momentum": snap.get("momentum", snap.get("ret_3")),
            "volume": snap.get("volume"),
            "volume_zscore": snap.get("volume_zscore", snap.get("volume_z_20")),
            "volatility": snap.get("volatility", snap.get("realized_vol_12")),
            "order_book_imbalance": snap.get("order_book_imbalance"),
            "p_up": p_up,
            "p_down": 1.0 - p_up,
            "probabilities_calibrated": bool(snap.get("probabilities_calibrated", False)),
            "up_bid": snap.get("up_bid"),
            "up_ask": snap.get("up_ask"),
            "down_bid": snap.get("down_bid"),
            "down_ask": snap.get("down_ask"),
            "up_ask_depth_usd": snap.get("up_ask_depth_usd", snap.get("top_size_usd")),
            "down_ask_depth_usd": snap.get("down_ask_depth_usd", snap.get("top_size_usd")),
            "up_bid_depth_usd": snap.get("up_bid_depth_usd"),
            "down_bid_depth_usd": snap.get("down_bid_depth_usd"),
            "quote_age_seconds": snap.get("quote_age_seconds"),
            "btc_quote_age_seconds": snap.get("btc_quote_age_seconds"),
            "feed_timestamp_epoch": feed_epoch if math.isfinite(feed_epoch) else None,
            "received_at_epoch": receive_epoch if math.isfinite(receive_epoch) else None,
            "feed_to_decision_latency_ms": feed_to_decision,
            "feed_to_receive_latency_ms": decision_to_feed_receive,
            "state_before": state_before,
            "state_after": state_after,
            "event": event_type,
            "direction": direction,
            "reason": reason,
            "up_net_edge": values.get("up_edge"),
            "down_net_edge": values.get("down_edge"),
            "net_edge": values.get("net_edge"),
            "max_entry_price": values.get("max_entry_price"),
            "entry_ask": values.get("entry_ask"),
            "exit_bid": values.get("exit_bid"),
            "entry_depth_usd": values.get("entry_depth_usd"),
            "exit_depth_usd": values.get("exit_depth_usd"),
            "exposure_usd": values.get("exposure_usd"),
            "entry_fillable": values.get("entry_fillable"),
            "exit_fillable": values.get("exit_fillable"),
            "transition_type": values.get("transition_type"),
            "entry_number": values.get("entry_number"),
            "position_cap": values.get("position_cap"),
        }
        self.history.setdefault(market_id, []).append(event)
        return event

    def update(self, snap: dict[str, Any]) -> Optional[dict[str, Any]]:
        market = str(snap["market_id"])
        w = self.cfg.get("swing", {})
        s = self.cfg["signals"]
        r = self.cfg["risk"]
        state_before = self.current_state(market)

        decision_epoch = _finite(snap.get("decision_timestamp_epoch", snap.get("timestamp_epoch")))
        if not math.isfinite(decision_epoch):
            decision_epoch = datetime.now(timezone.utc).timestamp()
        signature = self._signature(snap)
        if signature == self.last_snapshot_signature.get(market):
            return None
        if decision_epoch < self.last_snapshot_epoch.get(market, float("-inf")):
            return None
        self.last_snapshot_signature[market] = signature
        self.last_snapshot_epoch[market] = decision_epoch

        p_up = _finite(snap.get("p_up"), 0.5)
        rem = int(_finite(snap.get("seconds_remaining"), 0))
        up_ask = _finite(snap.get("up_ask"), 1.0)
        down_ask = _finite(snap.get("down_ask"), 1.0)
        up_bid = _finite(snap.get("up_bid"))
        down_bid = _finite(snap.get("down_bid"))
        quote_age = _finite(snap.get("quote_age_seconds"), 999.0)
        btc_age = _finite(snap.get("btc_quote_age_seconds"), quote_age)
        imbalance = _finite(snap.get("order_book_imbalance"), 0.0)
        momentum = _finite(snap.get("momentum", snap.get("ret_3")), 0.0)
        volume = _finite(snap.get("volume"), 0.0)
        volume_z = _finite(snap.get("volume_zscore", snap.get("volume_z_20")))
        volatility = _finite(snap.get("volatility", snap.get("realized_vol_12")))
        up_ask_depth = _finite(
            snap.get("up_ask_depth_usd", snap.get("top_size_usd")), 0.0
        )
        down_ask_depth = _finite(
            snap.get("down_ask_depth_usd", snap.get("top_size_usd")), 0.0
        )
        up_bid_depth = _finite(snap.get("up_bid_depth_usd"), 0.0)
        down_bid_depth = _finite(snap.get("down_bid_depth_usd"), 0.0)
        calibrated = bool(snap.get("probabilities_calibrated", False))
        valid_probability = math.isfinite(p_up) and 0.0 <= p_up <= 1.0
        cost_per_share = float(s["fee_per_share_usd"]) + float(
            s.get("slippage_per_share_usd", 0.0)
        )
        up_edge = p_up - up_ask - cost_per_share
        down_edge = (1.0 - p_up) - down_ask - cost_per_share
        max_up_entry = p_up - cost_per_share - float(s["min_net_edge"])
        max_down_entry = (1.0 - p_up) - cost_per_share - float(s["min_net_edge"])

        quote_fresh = (
            0.0 <= quote_age <= float(s["max_signal_age_seconds"])
            and up_ask > 0.0
            and down_ask > 0.0
        )
        btc_fresh = 0.0 <= btc_age <= float(
            w.get("max_btc_data_age_seconds", s["max_signal_age_seconds"])
        )
        fresh = quote_fresh and btc_fresh
        entry_time_ok = int(s["min_seconds_remaining"]) <= rem <= int(
            s["max_seconds_remaining"]
        )
        min_depth = float(s["min_top_of_book_size_usd"])
        up_contract_ok = float(s["min_contract_price"]) <= up_ask <= float(
            s["max_contract_price"]
        )
        down_contract_ok = float(s["min_contract_price"]) <= down_ask <= float(
            s["max_contract_price"]
        )
        candle_up = self._candle_evidence(snap.get("candle_ohlc"), "UP", w)
        candle_down = self._candle_evidence(snap.get("candle_ohlc"), "DOWN", w)
        volume_ok = (
            volume > 0.0
            and math.isfinite(volume_z)
            and volume_z >= float(w.get("min_volume_zscore", -0.5))
        )
        volatility_ok = (
            math.isfinite(volatility)
            and float(w.get("min_realized_volatility", 0.0)) <= volatility
            <= float(w.get("max_realized_volatility", 0.01))
        )
        up_structure = (
            momentum > max(0.0, float(w.get("min_momentum_abs", 0.0)))
            and imbalance >= float(w.get("min_imbalance", 0.05))
            and candle_up
        )
        down_structure = (
            momentum < -max(0.0, float(w.get("min_momentum_abs", 0.0)))
            and imbalance <= -float(w.get("min_imbalance", 0.05))
            and candle_down
        )
        up_ok = (
            calibrated
            and valid_probability
            and fresh
            and entry_time_ok
            and volume_ok
            and volatility_ok
            and up_structure
            and up_contract_ok
            and up_ask_depth >= min_depth
            and not bool(snap.get("daily_loss_stop_hit", False))
            and p_up >= float(w.get("entry_up_probability", 0.72))
            and up_edge >= float(s["min_net_edge"])
        )
        down_ok = (
            calibrated
            and valid_probability
            and fresh
            and entry_time_ok
            and volume_ok
            and volatility_ok
            and down_structure
            and down_contract_ok
            and down_ask_depth >= min_depth
            and not bool(snap.get("daily_loss_stop_hit", False))
            and p_up <= float(w.get("entry_down_probability", 0.28))
            and down_edge >= float(s["min_net_edge"])
        )

        # Invalidation is intentionally faster than entry confirmation.
        exit_up = (
            (calibrated and valid_probability and p_up < float(w.get("exit_up_below", 0.48)))
            or (momentum < -float(w.get("exit_momentum_threshold", 0.0001)) and imbalance < -float(w.get("exit_imbalance_threshold", 0.15)))
            or not fresh
        )
        exit_down = (
            (calibrated and valid_probability and p_up > float(w.get("exit_down_above", 0.52)))
            or (momentum > float(w.get("exit_momentum_threshold", 0.0001)) and imbalance > float(w.get("exit_imbalance_threshold", 0.15)))
            or not fresh
        )

        # If a thesis was invalidated while quotes/depth were unusable, do not claim
        # a close or free the position slot until an executable bid is observed.
        pending_direction = self.pending_exit.get(market)
        if pending_direction:
            bid = up_bid if pending_direction == "UP" else down_bid
            bid_depth = up_bid_depth if pending_direction == "UP" else down_bid_depth
            exit_fillable = (
                quote_fresh
                and math.isfinite(bid)
                and bid > 0.0
                and bid_depth >= min_depth
            )
            if not exit_fillable:
                return None
            self.pending_exit.pop(market, None)
            self.open_positions.pop(market, None)
            self.states[market] = "HOLD"
            self.last_exit_direction[market] = pending_direction
            exit_event = self._emit(
                snap,
                event_type=f"EXIT_{pending_direction}",
                state_before=state_before,
                state_after="HOLD",
                direction=pending_direction,
                reason="Previously invalidated thesis; fresh executable bid/depth now available",
                decision_epoch=decision_epoch,
                values={"exit_bid": bid, "exit_depth_usd": bid_depth, "exit_fillable": True},
            )
            self.active_signal_id.pop(market, None)
            return exit_event

        if state_before in ("BUY_UP", "BUY_DOWN"):
            direction = "UP" if state_before == "BUY_UP" else "DOWN"
            invalidated = exit_up if direction == "UP" else exit_down
            if not invalidated:
                return None
            bid = up_bid if direction == "UP" else down_bid
            bid_depth = up_bid_depth if direction == "UP" else down_bid_depth
            exit_fillable = (
                quote_fresh
                and math.isfinite(bid)
                and bid > 0.0
                and bid_depth >= min_depth
            )
            has_paper_position = market in self.open_positions
            if not has_paper_position:
                self.states[market] = "HOLD"
                self.last_exit_direction[market] = direction
                event_type = f"{direction}_INVALIDATED"
                state_after = "HOLD"
                exit_fillable = False
                reason = "Directional signal invalidated; no fillable hypothetical paper position existed to close"
            elif exit_fillable:
                self.states[market] = "HOLD"
                self.open_positions.pop(market, None)
                self.last_exit_direction[market] = direction
                event_type = f"EXIT_{direction}"
                state_after = "HOLD"
                reason = "Directional thesis invalidated; executable bid and depth available"
            else:
                self.states[market] = f"EXIT_PENDING_{direction}"
                self.pending_exit[market] = direction
                event_type = f"{direction}_INVALIDATED"
                state_after = f"EXIT_PENDING_{direction}"
                reason = "Directional thesis invalidated, but no sufficiently fresh/executable exit quote; position remains pending"
            exit_event = self._emit(
                snap,
                event_type=event_type,
                state_before=state_before,
                state_after=state_after,
                direction=direction,
                reason=reason,
                decision_epoch=decision_epoch,
                values={"exit_bid": bid if math.isfinite(bid) else None, "exit_depth_usd": bid_depth, "exit_fillable": exit_fillable},
            )
            if state_after == "HOLD":
                self.active_signal_id.pop(market, None)
            return exit_event

        if state_before.startswith("EXIT_PENDING_"):
            return None

        candidate = "UP" if up_ok else "DOWN" if down_ok else None
        if candidate is None:
            self.confirmations[market] = []
            return None

        # Signature was stored above; distinct signatures are guaranteed by the early
        # duplicate check. Keep only the most recent required candidate confirmations.
        confirmations = self.confirmations.get(market, [])
        confirmations = (confirmations + [candidate])[-max(1, int(w.get("entry_confirm_updates", 2))) :]
        self.confirmations[market] = confirmations
        required = max(1, int(w.get("entry_confirm_updates", 2)))
        if len(confirmations) < required or any(item != candidate for item in confirmations):
            return None

        min_gap = float(w.get("min_seconds_between_entries", 3.0))
        if decision_epoch - self.last_entry_epoch.get(market, float("-inf")) < min_gap:
            return None
        max_positions = max(1, int(r.get("max_open_paper_positions", 1)))
        if market not in self.open_positions and len(self.open_positions) >= max_positions:
            return None

        bankroll = float(r["bankroll_usd"])
        exposure = bankroll * float(r["max_exposure_fraction_per_signal"])
        direction = candidate
        ask = up_ask if direction == "UP" else down_ask
        edge = up_edge if direction == "UP" else down_edge
        max_entry = max_up_entry if direction == "UP" else max_down_entry
        depth = up_ask_depth if direction == "UP" else down_ask_depth
        entry_fillable = ask <= max_entry and depth >= exposure
        prior_exit = self.last_exit_direction.get(market)
        entry_number = self.entry_counts.get(market, 0) + 1
        transition_type = (
            "NEW_ENTRY"
            if entry_number == 1
            else "REVERSAL"
            if prior_exit and prior_exit != direction
            else "RE_ENTRY"
        )
        self.entry_counts[market] = entry_number
        self.states[market] = f"BUY_{direction}"
        if entry_fillable:
            self.open_positions[market] = direction
        self.last_entry_epoch[market] = decision_epoch
        self.confirmations[market] = []
        entry_event = self._emit(
            snap,
            event_type=f"BUY_{direction}",
            state_before=state_before,
            state_after=f"BUY_{direction}",
            direction=direction,
            reason="Fresh calibrated probability, candle structure, momentum, volume, volatility, book depth and net edge confirmed",
            decision_epoch=decision_epoch,
            values={
                "net_edge": edge,
                "max_entry_price": max_entry,
                "entry_ask": ask,
                "entry_depth_usd": depth,
                "exposure_usd": exposure,
                "entry_fillable": entry_fillable,
                "transition_type": transition_type,
                "entry_number": entry_number,
                "position_cap": max_positions,
            },
        )
        self.active_signal_id[market] = entry_event["signal_id"]
        return entry_event
