from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class SignalTracker:
    """SQLite event ledger and hypothetical paper-trade accounting.

    Alerts and paper fills are deliberately separate records. An alert is never
    treated as a fill unless the coordinator explicitly validates executable ask
    price, displayed depth, and the global position/risk limits.
    """

    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path, timeout=10.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @staticmethod
    def _utc_now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="milliseconds")

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS signals (
                    signal_id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, market_id TEXT NOT NULL,
                    direction TEXT NOT NULL, probability REAL NOT NULL, entry_ask REAL NOT NULL,
                    net_edge REAL NOT NULL, max_entry_price REAL NOT NULL, exposure_usd REAL NOT NULL,
                    seconds_remaining INTEGER NOT NULL, status TEXT NOT NULL,
                    resolved_up INTEGER, pnl_usd REAL, payload_json TEXT NOT NULL
                )"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT, market_id TEXT,
                    timestamp TEXT, event TEXT, state_before TEXT, state_after TEXT,
                    payload_json TEXT
                )"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS paper_trades (
                    trade_id TEXT PRIMARY KEY, market_id TEXT, signal_id TEXT, direction TEXT,
                    entry_time TEXT, entry_quote REAL, assumed_fill REAL, exposure_usd REAL,
                    fillable INTEGER, exit_time TEXT, exit_quote REAL, fees REAL DEFAULT 0,
                    slippage REAL DEFAULT 0, gross_pnl REAL, net_pnl REAL, status TEXT,
                    shares REAL, entry_fees REAL DEFAULT 0, entry_slippage REAL DEFAULT 0,
                    fillability_reason TEXT, market_window_open TEXT, market_window_close TEXT,
                    entry_event_id TEXT, exit_event_id TEXT, mark_price REAL, mark_pnl REAL,
                    outcome TEXT, updated_at TEXT
                )"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS market_state (
                    market_id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, state TEXT NOT NULL,
                    seconds_remaining INTEGER, snapshot_json TEXT NOT NULL
                )"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS notifications (
                    event_id TEXT NOT NULL, chat_id TEXT NOT NULL, sent_at TEXT NOT NULL,
                    decision_to_telegram_ms REAL, PRIMARY KEY(event_id, chat_id)
                )"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS app_settings (
                    setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL
                )"""
            )
            self._ensure_columns(
                connection,
                "events",
                {"event_id": "TEXT"},
            )
            self._ensure_columns(
                connection,
                "paper_trades",
                {
                    "shares": "REAL",
                    "entry_fees": "REAL DEFAULT 0",
                    "entry_slippage": "REAL DEFAULT 0",
                    "fillability_reason": "TEXT",
                    "market_window_open": "TEXT",
                    "market_window_close": "TEXT",
                    "entry_event_id": "TEXT",
                    "exit_event_id": "TEXT",
                    "mark_price": "REAL",
                    "mark_pnl": "REAL",
                    "outcome": "TEXT",
                    "updated_at": "TEXT",
                },
            )
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_events_event_id ON events(event_id) WHERE event_id IS NOT NULL"
            )

    @staticmethod
    def _ensure_columns(
        connection: sqlite3.Connection, table: str, columns: dict[str, str]
    ) -> None:
        existing = {row[1] for row in connection.execute(f"PRAGMA table_info({table})")}
        for name, definition in columns.items():
            if name not in existing:
                connection.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")

    def record(self, signal: Any) -> None:
        data = signal.to_dict() if hasattr(signal, "to_dict") else dict(signal)
        with self._connect() as connection:
            connection.execute(
                """INSERT OR IGNORE INTO signals (
                    signal_id,timestamp,market_id,direction,probability,entry_ask,net_edge,
                    max_entry_price,exposure_usd,seconds_remaining,status,resolved_up,pnl_usd,payload_json
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    data["signal_id"],
                    data["timestamp"],
                    data["market_id"],
                    data["direction"],
                    data["probability"],
                    data["entry_ask"],
                    data["net_edge"],
                    data["max_entry_price"],
                    data["exposure_usd"],
                    data["seconds_remaining"],
                    data.get("status", "ALERTED_NOT_FILLED"),
                    None,
                    None,
                    json.dumps(data, default=str),
                ),
            )

    def record_event(self, event: dict[str, Any]) -> bool:
        event_id = str(event.get("event_id") or uuid.uuid4())
        with self._connect() as connection:
            cursor = connection.execute(
                """INSERT OR IGNORE INTO events (
                    event_id,market_id,timestamp,event,state_before,state_after,payload_json
                ) VALUES (?,?,?,?,?,?,?)""",
                (
                    event_id,
                    event["market_id"],
                    event["timestamp"],
                    event["event"],
                    event.get("state_before"),
                    event.get("state_after"),
                    json.dumps(event, default=str),
                ),
            )
            return cursor.rowcount == 1

    def update_market_state(
        self, market_id: str, timestamp: str, state: str, seconds_remaining: int, snapshot: dict[str, Any]
    ) -> None:
        payload = dict(snapshot)
        payload["market_id"] = market_id
        payload["timestamp"] = timestamp
        payload["seconds_remaining"] = int(seconds_remaining)
        payload["current_state"] = state
        if payload.get("p_up") is not None and payload.get("p_down") is None:
            payload["p_down"] = 1.0 - float(payload["p_up"])
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO market_state(market_id,timestamp,state,seconds_remaining,snapshot_json)
                   VALUES(?,?,?,?,?)
                   ON CONFLICT(market_id) DO UPDATE SET timestamp=excluded.timestamp,
                   state=excluded.state,seconds_remaining=excluded.seconds_remaining,
                   snapshot_json=excluded.snapshot_json""",
                (
                    market_id,
                    timestamp,
                    state,
                    int(seconds_remaining),
                    json.dumps(payload, default=str),
                ),
            )

    def all_market_states(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT market_id,state,snapshot_json FROM market_state ORDER BY timestamp"
            ).fetchall()
        return [
            {"market_id": row["market_id"], "state": row["state"], "snapshot": json.loads(row["snapshot_json"])}
            for row in rows
        ]

    def latest_market_state(self) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT snapshot_json FROM market_state ORDER BY timestamp DESC LIMIT 1"
            ).fetchone()
        return json.loads(row["snapshot_json"]) if row else None

    def market_state(self, market_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT snapshot_json FROM market_state WHERE market_id=?", (market_id,)
            ).fetchone()
        return json.loads(row["snapshot_json"]) if row else None

    def open_paper_trade(self, trade: dict[str, Any], max_open_positions: int = 1) -> str:
        entry_quote = float(trade["entry_quote"])
        exposure = float(trade["exposure_usd"])
        if not 0.0 <= entry_quote <= 1.0 or exposure <= 0.0:
            raise ValueError("entry_quote must be in [0,1] and exposure_usd must be positive")
        fillable = bool(trade.get("fillable"))
        status = str(trade.get("status") or ("OPEN" if fillable else "MISSED_ENTRY"))
        if fillable:
            with self._connect() as connection:
                count = connection.execute(
                    "SELECT COUNT(*) n FROM paper_trades WHERE status='OPEN'"
                ).fetchone()["n"]
                if count >= max(1, int(max_open_positions)):
                    fillable = False
                    status = "BLOCKED_POSITION_CAP"
                    trade = {**trade, "fillability_reason": "Global open paper-position cap reached"}
                elif not trade.get("assumed_fill") or float(trade["assumed_fill"]) <= 0:
                    raise ValueError("A fillable trade requires a positive assumed_fill")

        assumed_fill = trade.get("assumed_fill") if fillable else None
        if fillable and not 0.0 < float(assumed_fill) <= 1.0:
            raise ValueError("assumed_fill must be in (0,1] for a fillable binary contract")
        shares = (
            float(trade.get("shares") or (exposure / float(assumed_fill)))
            if fillable
            else None
        )
        now = self._utc_now()
        with self._connect() as connection:
            connection.execute(
                """INSERT OR IGNORE INTO paper_trades (
                    trade_id,market_id,signal_id,direction,entry_time,entry_quote,assumed_fill,
                    exposure_usd,fillable,fees,slippage,status,shares,entry_fees,entry_slippage,
                    fillability_reason,market_window_open,market_window_close,entry_event_id,updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    trade["trade_id"],
                    trade["market_id"],
                    trade.get("signal_id"),
                    trade["direction"],
                    trade["entry_time"],
                    float(trade["entry_quote"]),
                    assumed_fill,
                    exposure,
                    int(fillable),
                    float(trade.get("entry_fees", 0.0)),
                    float(trade.get("entry_slippage", 0.0)),
                    status,
                    shares,
                    float(trade.get("entry_fees", 0.0)),
                    float(trade.get("entry_slippage", 0.0)),
                    trade.get("fillability_reason"),
                    trade.get("market_window_open"),
                    trade.get("market_window_close"),
                    trade.get("entry_event_id"),
                    now,
                ),
            )
        return status

    def update_signal_status(self, signal_id: str, status: str, pnl_usd: float | None = None) -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE signals SET status=?,pnl_usd=COALESCE(?,pnl_usd) WHERE signal_id=?",
                (status, pnl_usd, signal_id),
            )

    def active_paper_trades(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM paper_trades WHERE status='OPEN' ORDER BY entry_time"
            ).fetchall()
        return [dict(row) for row in rows]

    def get_open_trade(self, market_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM paper_trades WHERE market_id=? AND status='OPEN' ORDER BY entry_time DESC LIMIT 1",
                (market_id,),
            ).fetchone()
        return dict(row) if row else None

    def close_paper_trade(
        self,
        trade_id: str,
        exit_time: str,
        exit_bid: float,
        fees_usd: float = 0.0,
        slippage_usd: float = 0.0,
        exit_event_id: str | None = None,
    ) -> dict[str, float]:
        """Close at an observed bid; subtract cumulative entry+exit costs."""
        if not 0.0 <= float(exit_bid) <= 1.0 or fees_usd < 0.0 or slippage_usd < 0.0:
            raise ValueError("exit_bid must be in [0,1] and fees/slippage cannot be negative")
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM paper_trades WHERE trade_id=?", (trade_id,)
            ).fetchone()
            if not row:
                raise KeyError(trade_id)
            if not row["fillable"] or row["status"] != "OPEN":
                raise ValueError("Trade is not an open, fillable paper position")
            shares = float(row["shares"] or (row["exposure_usd"] / row["assumed_fill"]))
            entry_quote = float(row["entry_quote"])
            gross = shares * (float(exit_bid) - entry_quote)
            total_fees = float(row["fees"] or 0.0) + float(fees_usd)
            total_slippage = float(row["slippage"] or 0.0) + float(slippage_usd)
            net = gross - total_fees - total_slippage
            connection.execute(
                """UPDATE paper_trades SET exit_time=?,exit_quote=?,fees=?,slippage=?,
                   gross_pnl=?,net_pnl=?,status='CLOSED',exit_event_id=?,updated_at=?
                   WHERE trade_id=?""",
                (
                    exit_time,
                    float(exit_bid),
                    total_fees,
                    total_slippage,
                    gross,
                    net,
                    exit_event_id,
                    self._utc_now(),
                    trade_id,
                ),
            )
            if row["signal_id"]:
                connection.execute(
                    "UPDATE signals SET status='CLOSED',pnl_usd=? WHERE signal_id=?",
                    (net, row["signal_id"]),
                )
            return {"gross_pnl": gross, "net_pnl": net, "shares": shares, "fees": total_fees, "slippage": total_slippage}

    def mark_to_market(
        self,
        market_id: str,
        bid: float,
        timestamp: str,
        estimated_exit_fees_usd: float = 0.0,
        estimated_exit_slippage_usd: float = 0.0,
    ) -> dict[str, float] | None:
        if not 0.0 <= float(bid) <= 1.0 or estimated_exit_fees_usd < 0.0 or estimated_exit_slippage_usd < 0.0:
            raise ValueError("mark bid must be in [0,1] and estimated costs cannot be negative")
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM paper_trades WHERE market_id=? AND status='OPEN' ORDER BY entry_time DESC LIMIT 1",
                (market_id,),
            ).fetchone()
            if not row:
                return None
            shares = float(row["shares"] or (row["exposure_usd"] / row["assumed_fill"]))
            gross = shares * (float(bid) - float(row["entry_quote"]))
            net = (
                gross
                - float(row["fees"] or 0.0)
                - float(row["slippage"] or 0.0)
                - float(estimated_exit_fees_usd)
                - float(estimated_exit_slippage_usd)
            )
            connection.execute(
                "UPDATE paper_trades SET mark_price=?,mark_pnl=?,updated_at=? WHERE trade_id=?",
                (float(bid), net, timestamp, row["trade_id"]),
            )
            return {"gross_pnl": gross, "net_pnl": net}

    def resolve_market(self, market_id: str, resolved_up: bool, resolved_at: str) -> list[dict[str, float]]:
        """Resolve all still-open paper trades at binary settlement, after official result."""
        results: list[dict[str, float]] = []
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM paper_trades WHERE market_id=? AND status='OPEN'", (market_id,)
            ).fetchall()
            for row in rows:
                shares = float(row["shares"] or (row["exposure_usd"] / row["assumed_fill"]))
                won = (row["direction"] == "UP" and resolved_up) or (
                    row["direction"] == "DOWN" and not resolved_up
                )
                payout = 1.0 if won else 0.0
                gross = shares * (payout - float(row["entry_quote"]))
                fees = float(row["fees"] or 0.0)
                slippage = float(row["slippage"] or 0.0)
                net = gross - fees - slippage
                connection.execute(
                    """UPDATE paper_trades SET exit_time=?,exit_quote=?,gross_pnl=?,net_pnl=?,
                       status='RESOLVED',outcome=?,updated_at=? WHERE trade_id=?""",
                    (resolved_at, payout, gross, net, "WON" if won else "LOST", self._utc_now(), row["trade_id"]),
                )
                if row["signal_id"]:
                    connection.execute(
                        "UPDATE signals SET status=?,resolved_up=?,pnl_usd=? WHERE signal_id=?",
                        ("WON" if won else "LOST", int(resolved_up), net, row["signal_id"]),
                    )
                results.append({"gross_pnl": gross, "net_pnl": net, "shares": shares})
        return results

    def resolve(self, signal_id: str, resolved_up: bool, fee_usd: float = 0.0) -> None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT direction,entry_ask,exposure_usd FROM signals WHERE signal_id=?", (signal_id,)
            ).fetchone()
            if not row:
                raise KeyError(signal_id)
            direction, price, exposure = row["direction"], float(row["entry_ask"]), float(row["exposure_usd"])
            won = (direction == "UP" and resolved_up) or (direction == "DOWN" and not resolved_up)
            pnl = exposure / price * (1.0 - price) if won else -exposure
            pnl -= float(fee_usd)
            connection.execute(
                "UPDATE signals SET status=?,resolved_up=?,pnl_usd=? WHERE signal_id=?",
                ("WON" if won else "LOST", int(resolved_up), pnl, signal_id),
            )

    def daily_pnl(self, date_utc: str | None = None) -> float:
        """Realized P/L plus today's last mark-to-market P/L on open paper positions."""
        date_utc = date_utc or datetime.now(timezone.utc).date().isoformat()
        with self._connect() as connection:
            row = connection.execute(
                """SELECT
                   COALESCE(SUM(CASE WHEN status IN ('CLOSED','RESOLVED') THEN net_pnl ELSE 0 END),0) realized,
                   COALESCE(SUM(CASE WHEN status='OPEN' AND substr(updated_at,1,10)=? THEN mark_pnl ELSE 0 END),0) unrealized
                   FROM paper_trades
                   WHERE (status IN ('CLOSED','RESOLVED') AND substr(exit_time,1,10)=?)
                      OR (status='OPEN' AND substr(updated_at,1,10)=?)""",
                (date_utc, date_utc, date_utc),
            ).fetchone()
        return float(row["realized"] or 0.0) + float(row["unrealized"] or 0.0)

    def can_open_position(
        self, *, max_open_positions: int = 1, daily_loss_stop_usd: float | None = None
    ) -> tuple[bool, str]:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT COUNT(*) n FROM paper_trades WHERE status='OPEN'"
            ).fetchone()
        if int(row["n"]) >= max(1, int(max_open_positions)):
            return False, "Global open paper-position cap reached"
        if daily_loss_stop_usd is not None and self.daily_pnl() <= -abs(float(daily_loss_stop_usd)):
            return False, "Daily paper loss stop reached"
        return True, "Risk limits clear"

    def notification_was_sent(self, event_id: str, chat_id: str) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT 1 FROM notifications WHERE event_id=? AND chat_id=?", (event_id, str(chat_id))
            ).fetchone()
        return row is not None

    def record_notification(
        self, event_id: str, chat_id: str, sent_at: str, decision_to_telegram_ms: float | None
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT OR IGNORE INTO notifications(event_id,chat_id,sent_at,decision_to_telegram_ms) VALUES(?,?,?,?)",
                (event_id, str(chat_id), sent_at, decision_to_telegram_ms),
            )

    def set_setting(self, key: str, value: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO app_settings(setting_key,setting_value) VALUES(?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
                (key, value),
            )

    def get_setting(self, key: str, default: str | None = None) -> str | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT setting_value FROM app_settings WHERE setting_key=?", (key,)
            ).fetchone()
        return row["setting_value"] if row else default

    def summary(self) -> dict[str, Any]:
        with self._connect() as connection:
            signal = connection.execute(
                """SELECT COUNT(*) n,SUM(CASE WHEN pnl_usd>0 THEN 1 ELSE 0 END) wins,COALESCE(SUM(pnl_usd),0) pnl
                   FROM signals WHERE status IN ('WON','LOST','CLOSED')"""
            ).fetchone()
            trades = connection.execute(
                """SELECT COUNT(*) total,
                   SUM(status IN ('CLOSED','RESOLVED')) closed,
                   SUM(status='OPEN') open_count,
                   SUM(status='MISSED_ENTRY') missed,
                   SUM(status IN ('BLOCKED_POSITION_CAP','BLOCKED_RISK')) blocked,
                   SUM(CASE WHEN status IN ('CLOSED','RESOLVED') AND net_pnl>0 THEN 1 ELSE 0 END) wins,
                   COALESCE(SUM(CASE WHEN status IN ('CLOSED','RESOLVED') THEN gross_pnl ELSE 0 END),0) gross,
                   COALESCE(SUM(CASE WHEN status IN ('CLOSED','RESOLVED') THEN net_pnl ELSE 0 END),0) net
                   FROM paper_trades"""
            ).fetchone()
            event_count = connection.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
            closed_rows = connection.execute(
                "SELECT net_pnl FROM paper_trades WHERE status IN ('CLOSED','RESOLVED') ORDER BY exit_time"
            ).fetchall()
        pnls = [float(row["net_pnl"] or 0.0) for row in closed_rows]
        cumulative = 0.0
        peak = 0.0
        max_drawdown = 0.0
        current_losing_streak = 0
        longest_losing_streak = 0
        for pnl in pnls:
            cumulative += pnl
            peak = max(peak, cumulative)
            max_drawdown = max(max_drawdown, peak - cumulative)
            current_losing_streak = current_losing_streak + 1 if pnl < 0 else 0
            longest_losing_streak = max(longest_losing_streak, current_losing_streak)
        return {
            "resolved_signals": int(signal["n"] or 0),
            "signal_wins": int(signal["wins"] or 0),
            "signal_pnl_usd": float(signal["pnl"] or 0.0),
            "paper_trades": int(trades["total"] or 0),
            "closed_trades": int(trades["closed"] or 0),
            "open_trades": int(trades["open_count"] or 0),
            "missed_entries": int(trades["missed"] or 0),
            "blocked_entries": int(trades["blocked"] or 0),
            "trade_wins": int(trades["wins"] or 0),
            "gross_pnl_usd": float(trades["gross"] or 0.0),
            "net_pnl_usd": float(trades["net"] or 0.0),
            "max_drawdown_usd": float(max_drawdown),
            "longest_losing_streak": int(longest_losing_streak),
            "event_count": int(event_count),
        }

    def market_performance(self, market_id: str | None = None) -> list[dict[str, Any]]:
        query = """SELECT market_id,COUNT(*) total,
                   SUM(status IN ('CLOSED','RESOLVED')) closed,
                   SUM(status='OPEN') open_count,
                   SUM(status='MISSED_ENTRY') missed,
                   SUM(status IN ('BLOCKED_POSITION_CAP','BLOCKED_RISK')) blocked,
                   SUM(CASE WHEN status IN ('CLOSED','RESOLVED') AND net_pnl>0 THEN 1 ELSE 0 END) wins,
                   COALESCE(SUM(CASE WHEN status IN ('CLOSED','RESOLVED') THEN gross_pnl ELSE 0 END),0) gross,
                   COALESCE(SUM(CASE WHEN status IN ('CLOSED','RESOLVED') THEN net_pnl ELSE 0 END),0) net
                   FROM paper_trades"""
        params: tuple[Any, ...] = ()
        if market_id is not None:
            query += " WHERE market_id=?"
            params = (market_id,)
        query += " GROUP BY market_id ORDER BY market_id"
        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [
            {
                "market_id": row["market_id"],
                "trades": int(row["total"] or 0),
                "closed": int(row["closed"] or 0),
                "open": int(row["open_count"] or 0),
                "missed": int(row["missed"] or 0),
                "blocked": int(row["blocked"] or 0),
                "wins": int(row["wins"] or 0),
                "gross_pnl_usd": float(row["gross"] or 0.0),
                "net_pnl_usd": float(row["net"] or 0.0),
            }
            for row in rows
        ]

    def recent(self, limit: int = 10) -> list[tuple[Any, ...]]:
        with self._connect() as connection:
            return [
                tuple(row)
                for row in connection.execute(
                    """SELECT timestamp,market_id,direction,probability,entry_ask,status,pnl_usd
                       FROM signals ORDER BY timestamp DESC LIMIT ?""",
                    (limit,),
                )
            ]

    def recent_events_since(self, since_timestamp: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT payload_json FROM events WHERE timestamp>=? ORDER BY id DESC LIMIT ?",
                (since_timestamp, limit),
            ).fetchall()
        return [json.loads(row["payload_json"]) for row in rows]

    def recent_events(self, market_id: str | None = None, limit: int = 12) -> list[dict[str, Any]]:
        with self._connect() as connection:
            if market_id:
                rows = connection.execute(
                    "SELECT payload_json FROM events WHERE market_id=? ORDER BY id DESC LIMIT ?",
                    (market_id, limit),
                ).fetchall()
            else:
                rows = connection.execute(
                    "SELECT payload_json FROM events ORDER BY id DESC LIMIT ?", (limit,)
                ).fetchall()
        return [json.loads(row["payload_json"]) for row in rows]
