from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from .tracker import SignalTracker

load_dotenv()
log = logging.getLogger(__name__)


def _tracker() -> SignalTracker:
    return SignalTracker(os.getenv("FULLPROOF_DB_PATH", "data/fullproof.sqlite3"))


def allowed_chat_ids() -> set[str]:
    return {
        item.strip()
        for item in os.getenv("TELEGRAM_ALLOWED_CHAT_IDS", "").split(",")
        if item.strip()
    }


def is_authorized_chat(chat_id: Any) -> bool:
    allowed = allowed_chat_ids()
    return bool(allowed) and chat_id is not None and str(chat_id) in allowed


def notifications_paused(tracker: SignalTracker | None = None) -> bool:
    tracker = tracker or _tracker()
    return tracker.get_setting("notifications_paused", "0") == "1"


def _fmt_latency(value: Any) -> str:
    try:
        return f"{float(value):.0f} ms"
    except (TypeError, ValueError):
        return "not available"


def format_transition(event: dict[str, Any]) -> str:
    event_type = str(event.get("event", "HOLD"))
    transition = event.get("transition_type")
    if event_type == "BUY_UP":
        label = {
            "NEW_ENTRY": "NEW UP ENTRY",
            "RE_ENTRY": "UP RE-ENTRY",
            "REVERSAL": "REVERSAL → BUY UP",
        }.get(transition, "UP ENTRY")
    elif event_type == "BUY_DOWN":
        label = {
            "NEW_ENTRY": "NEW DOWN ENTRY",
            "RE_ENTRY": "DOWN RE-ENTRY",
            "REVERSAL": "REVERSAL → BUY DOWN",
        }.get(transition, "DOWN ENTRY")
    elif event_type == "EXIT_UP":
        label = (
            "EXIT UP — PAPER TRADE CLOSED"
            if event.get("paper_trade_status") == "CLOSED"
            else "EXIT UP — NO OPEN PAPER TRADE IN LEDGER"
        )
    elif event_type == "EXIT_DOWN":
        label = (
            "EXIT DOWN — PAPER TRADE CLOSED"
            if event.get("paper_trade_status") == "CLOSED"
            else "EXIT DOWN — NO OPEN PAPER TRADE IN LEDGER"
        )
    elif event_type == "UP_INVALIDATED":
        label = (
            "UP INVALIDATED — EXIT PENDING, NOT ASSUMED FILLED"
            if str(event.get("state_after", "")).startswith("EXIT_PENDING_")
            else "UP SIGNAL INVALIDATED — NO PAPER POSITION TO CLOSE"
        )
    elif event_type == "DOWN_INVALIDATED":
        label = (
            "DOWN INVALIDATED — EXIT PENDING, NOT ASSUMED FILLED"
            if str(event.get("state_after", "")).startswith("EXIT_PENDING_")
            else "DOWN SIGNAL INVALIDATED — NO PAPER POSITION TO CLOSE"
        )
    else:
        label = event_type.replace("_", " ")

    if event_type.startswith("BUY_"):
        paper_status = str(event.get("paper_trade_status", "PENDING"))
        if paper_status == "OPEN":
            label += " — PAPER POSITION OPEN (HYPOTHETICAL)"
        elif paper_status == "MISSED_ENTRY":
            label += " — ENTRY MISSED"
        elif paper_status.startswith("BLOCKED"):
            label += " — RISK BLOCKED"

    p_up = float(event.get("p_up", 0.5) or 0.5)
    p_down = float(event.get("p_down", 1.0 - p_up) or 0.0)
    remaining = int(event.get("seconds_remaining", 0))
    lines = [
        f"{label} | BTC 5m",
        f"Market: {event.get('market_id', 'unknown')}",
        f"State: {event.get('state_before', 'HOLD')} → {event.get('state_after', 'HOLD')}",
        f"UP probability: {p_up:.1%} | DOWN: {p_down:.1%}",
        f"UP bid/ask: {event.get('up_bid', '—')} / {event.get('up_ask', '—')}",
        f"DOWN bid/ask: {event.get('down_bid', '—')} / {event.get('down_ask', '—')}",
        f"Remaining: {remaining}s | Elapsed: {event.get('elapsed_seconds', '—')}s",
    ]
    if event_type.startswith("BUY_"):
        lines.extend(
            [
                f"Entry ask: {event.get('entry_ask', '—')} | Max acceptable: {event.get('max_entry_price', '—')}",
                f"Net edge: {float(event.get('net_edge') or 0):.1%} | Exposure cap: ${float(event.get('exposure_usd') or 0):.2f}",
                f"Displayed depth: ${float(event.get('entry_depth_usd') or 0):.2f} | Quote fillable: {bool(event.get('entry_fillable'))}",
                f"Paper ledger status: {event.get('paper_trade_status', 'PENDING')}",
            ]
        )
    elif event_type.startswith("EXIT_") or event_type.endswith("INVALIDATED"):
        lines.append(
            f"Exit bid: {event.get('exit_bid', '—')} | Exit depth: ${float(event.get('exit_depth_usd') or 0):.2f} | Executable: {bool(event.get('exit_fillable'))}"
        )
    lines.extend(
        [
            f"Feed → decision: {_fmt_latency(event.get('feed_to_decision_latency_ms'))}",
            f"Reason: {event.get('reason', '—')}",
            "PAPER RESEARCH ONLY — no order was placed; an alert is not a fill.",
        ]
    )
    return "\n".join(lines)


def format_current_status(snapshot: dict[str, Any] | None, events: list[dict[str, Any]] | None = None) -> str:
    if not snapshot:
        return (
            "FullProof Crypto | BTC 5m\n"
            "Current state: HOLD\n"
            "No market snapshots recorded yet. Feed is not connected."
        )
    state = str(snapshot.get("current_state", "HOLD"))
    if state == "HOLD":
        label = "HOLD — no qualified directional entry"
    elif state.startswith("BUY_"):
        direction = state.removeprefix("BUY_")
        paper_status = str(snapshot.get("paper_trade_status", "UNKNOWN"))
        if paper_status == "OPEN":
            label = f"POSITION CONTINUES — {direction} (HYPOTHETICAL PAPER POSITION)"
        elif paper_status == "MISSED_ENTRY":
            label = f"SIGNAL ACTIVE — {direction} (ENTRY MISSED; NO PAPER POSITION)"
        elif paper_status.startswith("BLOCKED"):
            label = f"SIGNAL ACTIVE — {direction} (PAPER ENTRY BLOCKED)"
        else:
            label = f"SIGNAL ACTIVE — {direction} (PAPER FILL STATUS UNKNOWN)"
    elif state.startswith("EXIT_PENDING_"):
        label = f"THESIS INVALIDATED — EXIT PENDING ({state.removeprefix('EXIT_PENDING_')})"
    else:
        label = state
    lines = [
        "FullProof Crypto | BTC 5m",
        f"Market: {snapshot.get('market_id', 'unknown')}",
        f"Current state: {label}",
        f"Remaining: {snapshot.get('seconds_remaining', '—')}s",
        f"UP / DOWN probability: {snapshot.get('p_up', '—')} / {snapshot.get('p_down', 1.0 - float(snapshot.get('p_up', 0.5)) if snapshot.get('p_up') is not None else '—')}",
        f"UP ask: {snapshot.get('up_ask', '—')} | DOWN ask: {snapshot.get('down_ask', '—')}",
        f"Last snapshot: {snapshot.get('timestamp', '—')}",
    ]
    if events:
        lines.append("Recent window events:")
        for item in events[-5:]:
            lines.append(
                f"• {item.get('timestamp', '')} | {item.get('event', '')} | {item.get('reason', '')}"
            )
    lines.append("Paper only — no orders are submitted.")
    return "\n".join(lines)


async def notify_transition(
    bot: Any, event: dict[str, Any], tracker: SignalTracker | None = None
) -> list[dict[str, Any]]:
    """Send one alert per event/chat and persist measured delivery latency."""
    tracker = tracker or _tracker()
    if notifications_paused(tracker):
        return []
    chat_ids = allowed_chat_ids()
    if not chat_ids:
        log.warning("Telegram notifications disabled: TELEGRAM_ALLOWED_CHAT_IDS is empty")
        return []

    event_id = str(event.get("event_id") or event.get("signal_id") or "")
    if not event_id:
        raise ValueError("A stable event_id is required for duplicate-safe Telegram delivery")
    base_text = format_transition(event)
    sent: list[dict[str, Any]] = []
    decision_epoch = event.get("timestamp_epoch")

    for chat_id in sorted(chat_ids):
        if tracker.notification_was_sent(event_id, chat_id):
            continue
        started = time.perf_counter()
        message = await bot.send_message(chat_id=int(chat_id), text=base_text)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        decision_to_telegram_ms = (
            max(0.0, (time.time() - float(decision_epoch)) * 1000.0)
            if decision_epoch is not None
            else elapsed_ms
        )
        # Best-effort append the measured wall-clock latency to the delivered alert.
        if message is not None and hasattr(bot, "edit_message_text"):
            try:
                await bot.edit_message_text(
                    chat_id=int(chat_id),
                    message_id=message.message_id,
                    text=base_text + f"\nDecision → Telegram: {decision_to_telegram_ms:.0f} ms",
                )
            except Exception:
                log.exception("Could not append delivery latency to Telegram event %s", event_id)
        tracker.record_notification(
            event_id,
            chat_id,
            datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            decision_to_telegram_ms,
        )
        sent.append(
            {
                "chat_id": chat_id,
                "send_call_ms": elapsed_ms,
                "decision_to_telegram_ms": decision_to_telegram_ms,
            }
        )
    return sent


async def _reply(update: Any, text: str) -> None:
    chat = getattr(update, "effective_chat", None)
    if chat is None or not is_authorized_chat(chat.id):
        return
    message = getattr(update, "effective_message", None)
    if message is not None:
        await message.reply_text(text)


async def start(update: Any, context: Any) -> None:
    await _reply(
        update,
        "FullProof Crypto | BTC 5m | PAPER / SIGNALS-ONLY\n"
        "No orders are placed. Commands: /status /signal /performance /today /pause /resume",
    )


async def status(update: Any, context: Any) -> None:
    tracker = _tracker()
    latest = tracker.latest_market_state()
    paused = notifications_paused(tracker)
    if latest:
        feed_status = f"Last snapshot: {latest.get('timestamp', 'unknown')}"
        current_state = latest.get("current_state", "HOLD")
        remaining = latest.get("seconds_remaining", "—")
    else:
        feed_status = "No snapshots recorded; feed not connected"
        current_state, remaining = "HOLD", "—"
    model_path = Path(os.getenv("FULLPROOF_MODEL_PATH", "models/btc_up_model.joblib"))
    await _reply(
        update,
        "FullProof Crypto | BTC 5m\n"
        f"Mode: PAPER | Notifications: {'PAUSED' if paused else 'ON'}\n"
        f"Current state: {current_state} | Remaining: {remaining}s\n"
        f"Market data: {feed_status}\n"
        f"Calibrated model artifact present: {model_path.exists()}\n"
        "Execution: disabled",
    )


async def signal(update: Any, context: Any) -> None:
    tracker = _tracker()
    latest = tracker.latest_market_state()
    events = tracker.recent_events(latest.get("market_id") if latest else None, 8)
    await _reply(update, format_current_status(latest, events))


async def performance(update: Any, context: Any) -> None:
    summary = _tracker().summary()
    closed = summary["closed_trades"]
    win_rate = 100.0 * summary["trade_wins"] / closed if closed else 0.0
    await _reply(
        update,
        "FullProof Crypto | PAPER PERFORMANCE\n"
        f"Paper trades: {summary['paper_trades']}\n"
        f"Closed/resolved: {closed} | Open: {summary['open_trades']}\n"
        f"Missed entries: {summary['missed_entries']} | Risk-blocked: {summary['blocked_entries']}\n"
        f"Closed-trade win rate: {win_rate:.1f}%\n"
        f"Gross P/L: ${summary['gross_pnl_usd']:.2f}\n"
        f"Net P/L after logged costs: ${summary['net_pnl_usd']:.2f}\n"
        f"Max drawdown: ${summary['max_drawdown_usd']:.2f} | Longest losing streak: {summary['longest_losing_streak']}\n"
        f"Logged state events: {summary['event_count']}\n"
        "Unfilled alerts are excluded from trade P/L.",
    )


async def today(update: Any, context: Any) -> None:
    tracker = _tracker()
    today_utc = datetime.now(timezone.utc).date().isoformat() + "T00:00:00"
    rows = tracker.recent_events_since(today_utc, limit=30)
    if not rows:
        await _reply(update, "No state-transition events recorded yet.")
        return
    lines = ["Recent FullProof events:"]
    for event in rows:
        lines.append(
            f"{event.get('timestamp', '')} | {event.get('market_id', '')} | "
            f"{event.get('event', '')} | {event.get('state_before', '')}→{event.get('state_after', '')}"
        )
    await _reply(update, "\n".join(lines))


async def pause(update: Any, context: Any) -> None:
    if not is_authorized_chat(getattr(getattr(update, "effective_chat", None), "id", None)):
        return
    _tracker().set_setting("notifications_paused", "1")
    await _reply(update, "Signal notifications paused. Paper tracking remains enabled.")


async def resume(update: Any, context: Any) -> None:
    if not is_authorized_chat(getattr(getattr(update, "effective_chat", None), "id", None)):
        return
    _tracker().set_setting("notifications_paused", "0")
    await _reply(update, "Signal notifications resumed. Paper mode remains enabled.")


def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise SystemExit("Set TELEGRAM_BOT_TOKEN in .env; never paste it into chat.")
    if not allowed_chat_ids():
        raise SystemExit("Set TELEGRAM_ALLOWED_CHAT_IDS; the bot fails closed without an allowlist.")
    try:
        from telegram.ext import Application, CommandHandler
    except ImportError as exc:
        raise SystemExit("Install project dependencies with: pip install -e .") from exc

    application = Application.builder().token(token).build()
    for command, handler in [
        ("start", start),
        ("status", status),
        ("signal", signal),
        ("performance", performance),
        ("today", today),
        ("pause", pause),
        ("resume", resume),
    ]:
        application.add_handler(CommandHandler(command, handler))
    application.run_polling()


if __name__ == "__main__":
    main()
