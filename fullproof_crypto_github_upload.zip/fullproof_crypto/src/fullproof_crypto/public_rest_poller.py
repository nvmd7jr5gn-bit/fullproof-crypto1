"""Conservative polling fallback for Polymarket US public REST market data.

This is not a substitute for a confirmed public market-data WebSocket. It preserves
raw venue payloads, records local receive/round-trip timing, avoids overlapping
requests, and backs off on errors. No order or account endpoints are called.
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .polymarket_us_public import PolymarketUSPublicClient

log = logging.getLogger(__name__)


def _fingerprint(value: Any) -> str:
    canonical = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class PublicMarketSnapshot:
    market_slug: str
    observed_at_utc: str
    observed_at_unix_ms: int
    request_duration_ms: float
    bbo: dict[str, Any]
    book: dict[str, Any] | None
    payload_fingerprint: str
    bbo_changed: bool
    book_changed: bool | None
    changed: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class JsonlSnapshotSink:
    """Append raw snapshots as JSON Lines; create parent directory if needed."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def __call__(self, snapshot: PublicMarketSnapshot) -> None:
        line = json.dumps(snapshot.to_dict(), sort_keys=True, separators=(",", ":"), default=str)
        with self._lock, self.path.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")


class PublicRestPoller:
    """Poll one manually verified market slug at a configurable research cadence.

    `interval_seconds` and `book_every_n` are engineering defaults, not venue-published
    limits. Confirm Polymarket's public REST limits before increasing cadence.
    """

    def __init__(
        self,
        client: PolymarketUSPublicClient,
        market_slug: str,
        *,
        interval_seconds: float = 2.0,
        book_every_n: int = 5,
        max_backoff_seconds: float = 60.0,
        clock: Callable[[], float] = time.time,
        monotonic: Callable[[], float] = time.monotonic,
    ):
        if not market_slug.strip():
            raise ValueError("market_slug is required")
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        if book_every_n < 1:
            raise ValueError("book_every_n must be at least 1")
        if max_backoff_seconds < interval_seconds:
            raise ValueError("max_backoff_seconds must be >= interval_seconds")
        self.client = client
        self.market_slug = market_slug
        self.interval_seconds = interval_seconds
        self.book_every_n = book_every_n
        self.max_backoff_seconds = max_backoff_seconds
        self.clock = clock
        self.monotonic = monotonic
        self._counter = 0
        self._last_bbo_fingerprint: str | None = None
        self._last_book_fingerprint: str | None = None
        self._last_book: dict[str, Any] | None = None

    def poll_once(self) -> PublicMarketSnapshot:
        started = self.monotonic()
        bbo = self.client.get_bbo(self.market_slug)
        self._counter += 1
        book: dict[str, Any] | None = None
        book_changed: bool | None = None
        if self._counter % self.book_every_n == 0:
            book = self.client.get_book(self.market_slug)
            book_fp = _fingerprint(book)
            book_changed = book_fp != self._last_book_fingerprint
            self._last_book_fingerprint = book_fp
            self._last_book = book

        bbo_fp = _fingerprint(bbo)
        bbo_changed = bbo_fp != self._last_bbo_fingerprint
        self._last_bbo_fingerprint = bbo_fp
        received = self.clock()
        duration_ms = max(0.0, (self.monotonic() - started) * 1000.0)
        canonical = json.dumps(
            {"bbo": bbo, "latest_book": self._last_book},
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        payload_fp = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        changed = bbo_changed or bool(book_changed)
        return PublicMarketSnapshot(
            market_slug=self.market_slug,
            observed_at_utc=datetime.fromtimestamp(received, timezone.utc).isoformat(),
            observed_at_unix_ms=int(received * 1000),
            request_duration_ms=duration_ms,
            bbo=bbo,
            book=book,
            payload_fingerprint=payload_fp,
            bbo_changed=bbo_changed,
            book_changed=book_changed,
            changed=changed,
        )

    def run_forever(
        self,
        on_snapshot: Callable[[PublicMarketSnapshot], None],
        stop_event: threading.Event,
    ) -> None:
        """Run sequentially until stopped; errors trigger bounded exponential backoff."""
        backoff = self.interval_seconds
        while not stop_event.is_set():
            started = self.monotonic()
            try:
                snapshot = self.poll_once()
                on_snapshot(snapshot)
                backoff = self.interval_seconds
                delay = max(0.0, self.interval_seconds - (self.monotonic() - started))
            except Exception:
                log.exception("Public REST poll failed for %s", self.market_slug)
                delay = min(max(backoff, self.interval_seconds), self.max_backoff_seconds)
                backoff = min(delay * 2.0, self.max_backoff_seconds)
            stop_event.wait(delay)


def snapshot_callback_for_jsonl(path: str | Path) -> Callable[[PublicMarketSnapshot], None]:
    return JsonlSnapshotSink(path)
