from __future__ import annotations

from pathlib import Path
from typing import Iterable

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .features import FEATURE_COLUMNS


class QuantProbabilityModel:
    """Two-model ensemble with a strictly later, out-of-sample Platt calibrator.

    When `groups` (normally market IDs) are supplied, an entire market is kept in
    either the base-model fit segment or the calibration segment. This avoids
    putting highly correlated snapshots from the same 5-minute contract on both
    sides of the calibration boundary.
    """

    def __init__(self, random_state: int = 42, calibration_fraction: float = 0.20):
        if not 0.05 <= calibration_fraction <= 0.40:
            raise ValueError("calibration_fraction must be between 0.05 and 0.40")
        self.random_state = random_state
        self.calibration_fraction = calibration_fraction
        self.linear = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                ("scale", StandardScaler()),
                (
                    "model",
                    LogisticRegression(
                        C=0.25,
                        max_iter=2000,
                        class_weight="balanced",
                        random_state=random_state,
                    ),
                ),
            ]
        )
        self.boost = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                (
                    "model",
                    HistGradientBoostingClassifier(
                        max_iter=150,
                        learning_rate=0.04,
                        max_leaf_nodes=15,
                        l2_regularization=2.0,
                        random_state=random_state,
                    ),
                ),
            ]
        )
        self.calibrator = LogisticRegression(C=1.0, max_iter=1000)
        self.is_fitted = False
        self.is_calibrated = False
        self.calibration_method = "platt_sigmoid_on_held_out_chronological_segment"

    @staticmethod
    def _group_split_indices(groups: Iterable[object] | None, n_rows: int, fraction: float) -> int:
        """Return a row boundary that never splits a contiguous group."""
        if groups is None:
            split = int(n_rows * (1.0 - fraction))
            return split

        group_values = pd.Series(list(groups)).reset_index(drop=True)
        if len(group_values) != n_rows:
            raise ValueError("groups length must match the training rows")
        if group_values.isna().any():
            raise ValueError("groups cannot contain missing values")

        # A market should appear in one contiguous block in chronological data.
        collapsed = group_values.ne(group_values.shift()).cumsum()
        block_values = group_values.groupby(collapsed, sort=False).first().tolist()
        if len(block_values) != len(set(block_values)):
            raise ValueError("Each market/group must occupy one contiguous chronological block")
        if len(block_values) < 4:
            raise ValueError("At least four distinct chronological groups are required for calibration")

        calibration_groups = max(1, int(np.ceil(len(block_values) * fraction)))
        calibration_groups = min(calibration_groups, len(block_values) - 2)
        first_calibration_group = len(block_values) - calibration_groups
        split = int(group_values.isin(block_values[:first_calibration_group]).sum())
        return split

    def _raw(self, x: pd.DataFrame) -> np.ndarray:
        x = x[FEATURE_COLUMNS]
        p_linear = self.linear.predict_proba(x)[:, 1]
        p_boost = self.boost.predict_proba(x)[:, 1]
        return np.clip(0.5 * p_linear + 0.5 * p_boost, 1e-5, 1 - 1e-5)

    def fit(self, x: pd.DataFrame, y, groups: Iterable[object] | None = None):
        missing = set(FEATURE_COLUMNS) - set(x.columns)
        if missing:
            raise ValueError(f"Missing model features: {sorted(missing)}")
        x = x[FEATURE_COLUMNS].reset_index(drop=True)
        y = pd.Series(y).astype(int).reset_index(drop=True)
        if len(x) != len(y):
            raise ValueError("features and target lengths differ")
        if len(x) < 2000:
            raise ValueError("At least 2,000 timestamped training rows are required")
        if not set(y.unique()).issubset({0, 1}) or y.nunique() != 2:
            raise ValueError("Training target must contain both binary outcome classes")

        if groups is None:
            raise ValueError("market_id groups are required to prevent same-market calibration leakage")
        group_values = list(groups)
        if len(group_values) != len(y):
            raise ValueError("groups length must match the training rows")
        group_target_counts = pd.DataFrame({"group": group_values, "target": y}).groupby("group")["target"].nunique()
        if group_target_counts.gt(1).any():
            raise ValueError("Each resolved market group must have one consistent target")
        split = self._group_split_indices(group_values, len(x), self.calibration_fraction)
        if split < 1000 or len(x) - split < 100:
            raise ValueError("Insufficient chronological base-fit or calibration rows")
        y_fit, y_cal = y.iloc[:split], y.iloc[split:]
        if y_fit.nunique() != 2 or y_cal.nunique() != 2:
            raise ValueError("Both base-fit and calibration segments must contain both classes")

        self.linear.fit(x.iloc[:split], y_fit)
        self.boost.fit(x.iloc[:split], y_fit)

        # Calibrator sees only later, out-of-sample predictions from frozen base models.
        raw_cal = self._raw(x.iloc[split:]).reshape(-1, 1)
        self.calibrator.fit(raw_cal, y_cal)
        self.fit_rows_ = int(split)
        self.calibration_rows_ = int(len(x) - split)
        self.fit_groups_ = len(set(group_values[:split]))
        self.calibration_groups_ = len(set(group_values[split:]))
        self.is_fitted = True
        self.is_calibrated = True
        return self

    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        if not self.is_fitted or not self.is_calibrated:
            raise RuntimeError("Model is not trained and calibrated; no signals may be generated")
        raw = self._raw(x).reshape(-1, 1)
        p_up = np.clip(self.calibrator.predict_proba(raw)[:, 1], 0.001, 0.999)
        return np.column_stack([1.0 - p_up, p_up])

    def save(self, path: str | Path) -> None:
        if not self.is_fitted or not self.is_calibrated:
            raise RuntimeError("Refusing to save an uncalibrated model")
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, target)

    @staticmethod
    def load(path: str | Path) -> "QuantProbabilityModel":
        model = joblib.load(path)
        if (
            not isinstance(model, QuantProbabilityModel)
            or not model.is_fitted
            or not getattr(model, "is_calibrated", False)
        ):
            raise ValueError("Model artifact is invalid, untrained, or uncalibrated")
        return model
