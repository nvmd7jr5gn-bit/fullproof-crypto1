"""Unauthenticated, read-only Polymarket US public REST client.

Only public gateway endpoints are implemented here. This module intentionally has
no order, account, wallet, or credential functionality.
"""
from __future__ import annotations

import json
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen


class PolymarketUSPublicAPIError(RuntimeError):
    """Raised when the public Polymarket US API cannot be queried."""


class PolymarketUSPublicClient:
    BASE_URL = "https://gateway.polymarket.us"

    def __init__(self, timeout: float = 10.0, base_url: str | None = None):
        self.timeout = timeout
        self.base_url = (base_url or self.BASE_URL).rstrip("/")

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        if params:
            clean = {k: v for k, v in params.items() if v is not None}
            if clean:
                url += "?" + urlencode(clean, doseq=True)
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "FullProofCrypto/0.1"})
        try:
            with urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise PolymarketUSPublicAPIError(f"Public API request failed for {path}: {exc}") from exc
        if not isinstance(payload, dict):
            raise PolymarketUSPublicAPIError(f"Unexpected non-object response from {path}")
        return payload

    def get_markets(self, *, active: bool | None = True, closed: bool | None = False,
                    limit: int = 100, offset: int = 0, **filters: Any) -> dict[str, Any]:
        if limit < 1 or limit > 500:
            raise ValueError("limit must be between 1 and 500")
        if offset < 0:
            raise ValueError("offset cannot be negative")
        params = {"active": str(active).lower() if active is not None else None,
                  "closed": str(closed).lower() if closed is not None else None,
                  "limit": limit, "offset": offset, **filters}
        return self._get("/v1/markets", params)

    def get_market(self, slug: str) -> dict[str, Any]:
        if not slug.strip():
            raise ValueError("market slug is required")
        return self._get(f"/v1/market/slug/{quote(slug.strip(), safe='')}")

    def get_bbo(self, slug: str) -> dict[str, Any]:
        if not slug.strip():
            raise ValueError("market slug is required")
        return self._get(f"/v1/markets/{quote(slug.strip(), safe='')}/bbo")

    def get_book(self, slug: str) -> dict[str, Any]:
        if not slug.strip():
            raise ValueError("market slug is required")
        return self._get(f"/v1/markets/{quote(slug.strip(), safe='')}/book")

    def get_settlement(self, slug: str) -> dict[str, Any]:
        if not slug.strip():
            raise ValueError("market slug is required")
        return self._get(f"/v1/markets/{quote(slug.strip(), safe='')}/settlement")
