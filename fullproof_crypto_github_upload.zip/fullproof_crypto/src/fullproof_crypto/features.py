from __future__ import annotations
import numpy as np
import pandas as pd

FEATURE_COLUMNS = [
    "ret_1", "ret_3", "ret_6", "ema_spread", "rsi_14",
    "realized_vol_12", "volume_z_20", "distance_from_open",
    "order_book_imbalance", "seconds_remaining_norm",
]

def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).fillna(50)

def build_features(frame: pd.DataFrame) -> pd.DataFrame:
    required = {
        "btc_price", "market_open_price", "volume", "bid_size",
        "ask_size", "seconds_remaining"
    }
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Missing feature columns: {sorted(missing)}")

    x = frame.copy()
    px = pd.to_numeric(x["btc_price"], errors="coerce")
    logret = np.log(px / px.shift(1))
    x["ret_1"] = logret
    x["ret_3"] = np.log(px / px.shift(3))
    x["ret_6"] = np.log(px / px.shift(6))
    ema_fast = px.ewm(span=9, adjust=False).mean()
    ema_slow = px.ewm(span=21, adjust=False).mean()
    x["ema_spread"] = (ema_fast - ema_slow) / px
    x["rsi_14"] = _rsi(px, 14) / 100.0
    x["realized_vol_12"] = logret.rolling(12, min_periods=4).std()
    vol = pd.to_numeric(x["volume"], errors="coerce")
    vol_mean = vol.rolling(20, min_periods=5).mean()
    vol_std = vol.rolling(20, min_periods=5).std().replace(0, np.nan)
    x["volume_z_20"] = ((vol - vol_mean) / vol_std).clip(-5, 5)
    x["distance_from_open"] = (
        px - pd.to_numeric(x["market_open_price"], errors="coerce")
    ) / pd.to_numeric(x["market_open_price"], errors="coerce")
    bid = pd.to_numeric(x["bid_size"], errors="coerce")
    ask = pd.to_numeric(x["ask_size"], errors="coerce")
    denom = (bid + ask).replace(0, np.nan)
    x["order_book_imbalance"] = ((bid - ask) / denom).fillna(0)
    x["seconds_remaining_norm"] = (
        pd.to_numeric(x["seconds_remaining"], errors="coerce") / 300.0
    ).clip(0, 1)
    return x.replace([np.inf, -np.inf], np.nan)
