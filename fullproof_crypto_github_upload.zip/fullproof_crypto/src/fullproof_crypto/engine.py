from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import pandas as pd

from .features import FEATURE_COLUMNS
from .strategy import Signal, SwingStateMachine
from .tracker import SignalTracker


class PaperSignalCoordinator:
    """Connect normalized, calibrated snapshots to events and paper accounting.

    This coordinator does not fetch market data or place orders. A future adapter must
    supply a point-in-time snapshot with verified outcome mapping, calibrated p_up,
    executable UP/DOWN BBO/depth, BTC features, and official market-window metadata.
    """

    def __init__(
        self,
        config: dict[str, Any],
        tracker: SignalTracker | None = None,
        model: Any | None = None,
    ):
        self.config = config
        self.model = model
        self.tracker = tracker or SignalTracker(config["tracking"]["database_path"])
        self.state_machine = SwingStateMachine(config)
        # Restore per-market entry counts, last exit direction, and active/pending state
        # so a process restart does not silently forget a paper position or label a
        # same-window re-entry as a brand-new first entry.
        for market_state in self.tracker.all_market_states():
            market_id = market_state["market_id"]
            events = list(reversed(self.tracker.recent_events(market_id, limit=1000)))
            entries = [item for item in events if str(item.get("event", "")).startswith("BUY_")]
            exits = [
                item for item in events
                if item.get("event") in ("EXIT_UP", "EXIT_DOWN", "UP_INVALIDATED", "DOWN_INVALIDATED")
            ]
            self.state_machine.entry_counts[market_id] = len(entries)
            if entries:
                latest_entry = entries[-1]
                self.state_machine.last_entry_epoch[market_id] = float(
                    latest_entry.get("timestamp_epoch", 0.0)
                )
            if exits:
                self.state_machine.last_exit_direction[market_id] = str(exits[-1].get("direction"))
            state = str(market_state["state"])
            if state.startswith("BUY_") or state.startswith("EXIT_PENDING_"):
                direction = state.split("_", 2)[-1]
                latest_signal_id = entries[-1].get("signal_id") if entries else None
                has_open_trade = self.tracker.get_open_trade(market_id) is not None
                self.state_machine.restore_open_position(
                    market_id,
                    direction,
                    signal_id=latest_signal_id,
                    pending_exit=state.startswith("EXIT_PENDING_"),
                    occupies_position=has_open_trade,
                )

    @staticmethod
    def _timestamp() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="milliseconds")

    def process_snapshot(self, snapshot: dict[str, Any]) -> dict[str, Any] | None:
        snapshot = dict(snapshot)
        if self.model is not None:
            features = snapshot.get("model_features")
            if features is None and all(key in snapshot for key in FEATURE_COLUMNS):
                features = {key: snapshot[key] for key in FEATURE_COLUMNS}
            if features is not None:
                prediction = self.model.predict_proba(pd.DataFrame([features]))[0]
                snapshot["p_up"] = float(prediction[1])
                snapshot["p_down"] = float(prediction[0])
                snapshot["probabilities_calibrated"] = bool(
                    getattr(self.model, "is_calibrated", False)
                )
        risk = self.config["risk"]
        daily_stop = float(risk["bankroll_usd"]) * float(risk["daily_loss_stop_fraction"])
        snapshot["daily_loss_stop_hit"] = self.tracker.daily_pnl() <= -daily_stop
        market_id = str(snapshot["market_id"])
        previous_snapshot = self.tracker.market_state(market_id) or {}
        event = self.state_machine.update(snapshot)
        state = self.state_machine.current_state(market_id)
        timestamp = event["timestamp"] if event else self._timestamp()
        if event is None:
            snapshot["paper_trade_status"] = previous_snapshot.get("paper_trade_status")
            snapshot["last_event"] = previous_snapshot.get("last_event")
            self.tracker.update_market_state(
                market_id,
                timestamp,
                state,
                int(snapshot.get("seconds_remaining", 0)),
                snapshot,
            )
            # Mark-to-market only on fresh bids. Estimated exit costs are included;
            # no trade is closed and no fill is assumed by this mark.
            quote_age = float(snapshot.get("quote_age_seconds", 999.0))
            if quote_age <= float(self.config["signals"]["max_signal_age_seconds"]):
                fee = float(self.config["signals"].get("fee_per_share_usd", 0.0))
                slip = float(self.config["signals"].get("slippage_per_share_usd", 0.0))
                if state == "BUY_UP" and snapshot.get("up_bid") is not None:
                    trade = self.tracker.get_open_trade(market_id)
                    shares = float(trade["shares"] or 0.0) if trade else 0.0
                    self.tracker.mark_to_market(
                        market_id, float(snapshot["up_bid"]), timestamp,
                        estimated_exit_fees_usd=shares * fee,
                        estimated_exit_slippage_usd=shares * slip,
                    )
                elif state == "BUY_DOWN" and snapshot.get("down_bid") is not None:
                    trade = self.tracker.get_open_trade(market_id)
                    shares = float(trade["shares"] or 0.0) if trade else 0.0
                    self.tracker.mark_to_market(
                        market_id, float(snapshot["down_bid"]), timestamp,
                        estimated_exit_fees_usd=shares * fee,
                        estimated_exit_slippage_usd=shares * slip,
                    )
            return None

        if event["event"] in ("BUY_UP", "BUY_DOWN"):
            self._record_entry(event)
        elif event["event"] in ("EXIT_UP", "EXIT_DOWN") and event.get("exit_fillable"):
            self._record_exit(event)
        elif event["event"] in ("UP_INVALIDATED", "DOWN_INVALIDATED"):
            event["paper_trade_status"] = (
                "EXIT_PENDING"
                if str(event.get("state_after", "")).startswith("EXIT_PENDING_")
                else "NO_OPEN_PAPER_TRADE"
            )
        snapshot["paper_trade_status"] = event.get("paper_trade_status")
        snapshot["last_event"] = event
        self.tracker.update_market_state(
            market_id,
            timestamp,
            state,
            int(snapshot.get("seconds_remaining", 0)),
            snapshot,
        )
        self.tracker.record_event(event)
        return event

    def _record_entry(self, event: dict[str, Any]) -> None:
        direction = event["direction"]
        ask = float(event["entry_ask"])
        exposure = float(event["exposure_usd"])
        probability = float(event["p_up"] if direction == "UP" else event["p_down"])
        signal = Signal(
            signal_id=event["signal_id"],
            timestamp=event["timestamp"],
            market_id=event["market_id"],
            direction=direction,
            probability=probability,
            entry_ask=ask,
            net_edge=float(event["net_edge"]),
            max_entry_price=float(event["max_entry_price"]),
            exposure_usd=exposure,
            seconds_remaining=int(event["seconds_remaining"]),
        )
        self.tracker.record(signal)

        risk = self.config["risk"]
        daily_stop = float(risk["bankroll_usd"]) * float(risk["daily_loss_stop_fraction"])
        if event.get("entry_fillable"):
            allowed, risk_reason = self.tracker.can_open_position(
                max_open_positions=int(risk.get("max_open_paper_positions", 1)),
                daily_loss_stop_usd=daily_stop,
            )
        else:
            allowed, risk_reason = True, "Entry quote/depth was not fillable"
        slippage_per_share = float(self.config["signals"].get("slippage_per_share_usd", 0.0))
        fee_per_share = float(self.config["signals"].get("fee_per_share_usd", 0.0))
        assumed_fill = ask + slippage_per_share
        all_in_entry_cost_per_share = assumed_fill + fee_per_share
        fillable = (
            bool(event.get("entry_fillable"))
            and allowed
            and ask <= float(event["max_entry_price"])
            and all_in_entry_cost_per_share > 0
        )
        shares = exposure / all_in_entry_cost_per_share if fillable else 0.0
        if not event.get("entry_fillable"):
            reason = "Displayed ask/depth did not support the alert at decision time"
        elif not allowed:
            reason = risk_reason
        elif ask > float(event["max_entry_price"]):
            reason = "Quoted ask exceeded maximum acceptable entry"
        else:
            reason = "Hypothetical fillable at observed ask plus configured slippage; not an actual order"
        status = (
            "OPEN"
            if fillable
            else "BLOCKED_RISK"
            if event.get("entry_fillable") and not allowed
            else "MISSED_ENTRY"
        )
        final_status = self.tracker.open_paper_trade(
            {
                "trade_id": event["event_id"],
                "market_id": event["market_id"],
                "signal_id": event["signal_id"],
                "direction": direction,
                "entry_time": event["timestamp"],
                "entry_quote": ask,
                "assumed_fill": assumed_fill if fillable else None,
                "shares": shares if fillable else None,
                "exposure_usd": exposure,
                "fillable": fillable,
                "status": status,
                "entry_fees": shares * fee_per_share if fillable else 0.0,
                "entry_slippage": shares * slippage_per_share if fillable else 0.0,
                "fillability_reason": reason,
                "market_window_open": event.get("window_open"),
                "market_window_close": event.get("window_close"),
                "entry_event_id": event["event_id"],
            },
            max_open_positions=int(risk.get("max_open_paper_positions", 1)),
        )
        self.tracker.update_signal_status(event["signal_id"], final_status)
        event["paper_trade_status"] = final_status
        if final_status != "OPEN":
            self.state_machine.mark_entry_unfilled(event["market_id"])

    def _record_exit(self, event: dict[str, Any]) -> None:
        trade = self.tracker.get_open_trade(event["market_id"])
        if not trade:
            event["paper_trade_status"] = "NO_OPEN_PAPER_TRADE"
            return
        direction = event["direction"]
        exit_bid = float(event["exit_bid"])
        shares = float(trade["shares"] or 0.0)
        fee_per_share = float(self.config["signals"].get("fee_per_share_usd", 0.0))
        slippage_per_share = float(self.config["signals"].get("slippage_per_share_usd", 0.0))
        self.tracker.close_paper_trade(
            trade["trade_id"],
            event["timestamp"],
            exit_bid,
            fees_usd=shares * fee_per_share,
            slippage_usd=shares * slippage_per_share,
            exit_event_id=event["event_id"],
        )
        event["paper_trade_status"] = "CLOSED"

    def resolve_market(self, market_id: str, resolved_up: bool, resolved_at: str | None = None):
        """Call only after the exact official Polymarket US settlement is verified."""
        resolved_at = resolved_at or self._timestamp()
        prior_state = self.state_machine.current_state(market_id)
        results = self.tracker.resolve_market(market_id, resolved_up, resolved_at)
        self.state_machine.settle_market(market_id)
        current = self.tracker.market_state(market_id) or {"market_id": market_id}
        self.tracker.update_market_state(market_id, resolved_at, "HOLD", 0, {
            **current,
            "settled": True,
            "resolved_up": bool(resolved_up),
        })
        self.tracker.record_event({
            "event_id": f"settlement:{market_id}:{resolved_at}",
            "signal_id": None,
            "market_id": market_id,
            "timestamp": resolved_at,
            "timestamp_epoch": None,
            "event": "MARKET_RESOLVED",
            "state_before": prior_state,
            "state_after": "HOLD",
            "direction": None,
            "reason": "Official market resolution recorded; remaining paper positions settled",
            "resolved_up": bool(resolved_up),
        })
        return results
